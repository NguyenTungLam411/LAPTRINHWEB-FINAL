using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ToanTechWeb.Models.Entities;

/// <summary>
/// Hàng hoá / sản phẩm / dịch vụ do công ty cung cấp (yêu cầu 2 của đề bài).
/// </summary>
public class Product
{
    public int Id { get; set; }

    [Required(ErrorMessage = "Vui lòng nhập mã sản phẩm")]
    [StringLength(40)]
    [Display(Name = "Mã sản phẩm")]
    public string Sku { get; set; } = string.Empty;

    [Required(ErrorMessage = "Vui lòng nhập tên sản phẩm")]
    [StringLength(200)]
    [Display(Name = "Tên sản phẩm")]
    public string Name { get; set; } = string.Empty;

    [Required]
    [StringLength(220)]
    [Display(Name = "Slug")]
    public string Slug { get; set; } = string.Empty;

    [Display(Name = "Danh mục")]
    [Range(1, int.MaxValue, ErrorMessage = "Vui lòng chọn danh mục")]
    public int CategoryId { get; set; }

    [ForeignKey(nameof(CategoryId))]
    public Category? Category { get; set; }

    [StringLength(80)]
    [Display(Name = "Thương hiệu")]
    public string? Brand { get; set; }

    [StringLength(500)]
    [Display(Name = "Mô tả ngắn")]
    public string? ShortDescription { get; set; }

    /// <summary>Nội dung HTML, luôn được làm sạch bằng HtmlSanitizer trước khi lưu (chống XSS lưu trữ).</summary>
    [Display(Name = "Mô tả chi tiết")]
    public string? Description { get; set; }

    [Column(TypeName = "decimal(18,2)")]
    [Range(0, 999999999, ErrorMessage = "Giá bán phải lớn hơn hoặc bằng 0")]
    [Display(Name = "Giá bán")]
    public decimal Price { get; set; }

    [Column(TypeName = "decimal(18,2)")]
    [Display(Name = "Giá gốc")]
    public decimal? OldPrice { get; set; }

    [Range(0, int.MaxValue, ErrorMessage = "Số lượng tồn không hợp lệ")]
    [Display(Name = "Tồn kho")]
    public int StockQuantity { get; set; }

    [StringLength(255)]
    [Display(Name = "Ảnh đại diện")]
    public string? ImageUrl { get; set; }

    [Display(Name = "Sản phẩm nổi bật")]
    public bool IsFeatured { get; set; }

    [Display(Name = "Đang kinh doanh")]
    public bool IsActive { get; set; } = true;

    [Display(Name = "Lượt xem")]
    public int ViewCount { get; set; }

    public DateTime CreatedAt { get; set; } = DateTime.Now;
    public DateTime? UpdatedAt { get; set; }

    public ICollection<ProductImage> Images { get; set; } = new List<ProductImage>();
    public ICollection<OrderDetail> OrderDetails { get; set; } = new List<OrderDetail>();

    /// <summary>% giảm giá, tính từ giá gốc. Không ánh xạ xuống CSDL.</summary>
    [NotMapped]
    public int DiscountPercent =>
        OldPrice.HasValue && OldPrice.Value > Price && OldPrice.Value > 0
            ? (int)Math.Round((OldPrice.Value - Price) / OldPrice.Value * 100)
            : 0;

    [NotMapped]
    public bool InStock => StockQuantity > 0;
}

/// <summary>Ảnh phụ trong thư viện ảnh của sản phẩm.</summary>
public class ProductImage
{
    public int Id { get; set; }

    public int ProductId { get; set; }

    [ForeignKey(nameof(ProductId))]
    public Product? Product { get; set; }

    [Required]
    [StringLength(255)]
    [Display(Name = "Đường dẫn ảnh")]
    public string ImageUrl { get; set; } = string.Empty;

    [Display(Name = "Thứ tự")]
    public int DisplayOrder { get; set; }
}
