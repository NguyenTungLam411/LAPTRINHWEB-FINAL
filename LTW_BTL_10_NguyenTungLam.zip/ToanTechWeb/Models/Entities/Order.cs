using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ToanTechWeb.Models.Entities;

/// <summary>
/// Đơn hàng - phục vụ nghiệp vụ "tiếp nhận đơn hàng, xử lý bán hàng trực tuyến".
/// Khách vãng lai (UserId = null) và khách có tài khoản đều đặt được hàng.
/// </summary>
public class Order
{
    public int Id { get; set; }

    [Required]
    [StringLength(20)]
    [Display(Name = "Mã đơn hàng")]
    public string OrderCode { get; set; } = string.Empty;

    [Display(Name = "Tài khoản")]
    public string? UserId { get; set; }

    [ForeignKey(nameof(UserId))]
    public ApplicationUser? User { get; set; }

    [Required(ErrorMessage = "Vui lòng nhập họ tên người nhận")]
    [StringLength(100)]
    [Display(Name = "Họ tên người nhận")]
    public string CustomerName { get; set; } = string.Empty;

    [Required(ErrorMessage = "Vui lòng nhập số điện thoại")]
    [RegularExpression(@"^(0|\+84)[0-9]{9}$", ErrorMessage = "Số điện thoại không hợp lệ (VD: 0912345678)")]
    [StringLength(20)]
    [Display(Name = "Điện thoại")]
    public string CustomerPhone { get; set; } = string.Empty;

    [Required(ErrorMessage = "Vui lòng nhập email")]
    [EmailAddress(ErrorMessage = "Email không hợp lệ")]
    [StringLength(150)]
    [Display(Name = "Email")]
    public string CustomerEmail { get; set; } = string.Empty;

    [Required(ErrorMessage = "Vui lòng nhập địa chỉ giao hàng")]
    [StringLength(300)]
    [Display(Name = "Địa chỉ giao hàng")]
    public string ShippingAddress { get; set; } = string.Empty;

    [StringLength(500)]
    [Display(Name = "Ghi chú")]
    public string? Note { get; set; }

    [Display(Name = "Hình thức thanh toán")]
    public PaymentMethod PaymentMethod { get; set; } = PaymentMethod.CashOnDelivery;

    [Display(Name = "Trạng thái")]
    public OrderStatus Status { get; set; } = OrderStatus.Pending;

    [Column(TypeName = "decimal(18,2)")]
    [Display(Name = "Tiền hàng")]
    public decimal SubTotal { get; set; }

    [Column(TypeName = "decimal(18,2)")]
    [Display(Name = "Phí vận chuyển")]
    public decimal ShippingFee { get; set; }

    [Column(TypeName = "decimal(18,2)")]
    [Display(Name = "Tổng thanh toán")]
    public decimal TotalAmount { get; set; }

    [StringLength(500)]
    [Display(Name = "Lý do huỷ")]
    public string? CancelReason { get; set; }

    [Display(Name = "Ngày đặt")]
    public DateTime CreatedAt { get; set; } = DateTime.Now;

    [Display(Name = "Cập nhật lần cuối")]
    public DateTime? UpdatedAt { get; set; }

    public ICollection<OrderDetail> OrderDetails { get; set; } = new List<OrderDetail>();
}

public class OrderDetail
{
    public int Id { get; set; }

    public int OrderId { get; set; }

    [ForeignKey(nameof(OrderId))]
    public Order? Order { get; set; }

    public int ProductId { get; set; }

    [ForeignKey(nameof(ProductId))]
    public Product? Product { get; set; }

    /// <summary>Chụp lại tên và giá tại thời điểm mua, để đơn cũ không đổi khi sản phẩm đổi giá.</summary>
    [Required]
    [StringLength(200)]
    [Display(Name = "Tên sản phẩm")]
    public string ProductName { get; set; } = string.Empty;

    [Column(TypeName = "decimal(18,2)")]
    [Display(Name = "Đơn giá")]
    public decimal UnitPrice { get; set; }

    [Range(1, 1000, ErrorMessage = "Số lượng từ 1 đến 1000")]
    [Display(Name = "Số lượng")]
    public int Quantity { get; set; }

    [Column(TypeName = "decimal(18,2)")]
    [Display(Name = "Thành tiền")]
    public decimal LineTotal { get; set; }
}

public enum OrderStatus
{
    [Display(Name = "Chờ xác nhận")]
    Pending = 0,

    [Display(Name = "Đã xác nhận")]
    Confirmed = 1,

    [Display(Name = "Đang giao hàng")]
    Shipping = 2,

    [Display(Name = "Đã giao thành công")]
    Completed = 3,

    [Display(Name = "Đã huỷ")]
    Cancelled = 4
}

public enum PaymentMethod
{
    [Display(Name = "Thanh toán khi nhận hàng (COD)")]
    CashOnDelivery = 0,

    [Display(Name = "Chuyển khoản ngân hàng")]
    BankTransfer = 1
}
