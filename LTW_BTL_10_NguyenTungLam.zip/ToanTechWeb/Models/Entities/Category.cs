using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ToanTechWeb.Models.Entities;

/// <summary>
/// Danh mục hàng hoá / dịch vụ. Tự tham chiếu (ParentId) để tạo cây danh mục
/// nhiều cấp - đáp ứng yêu cầu "có nhiều chủng loại" của đề bài.
/// </summary>
public class Category
{
    public int Id { get; set; }

    [Required(ErrorMessage = "Vui lòng nhập tên danh mục")]
    [StringLength(120)]
    [Display(Name = "Tên danh mục")]
    public string Name { get; set; } = string.Empty;

    [Required]
    [StringLength(140)]
    [Display(Name = "Slug")]
    public string Slug { get; set; } = string.Empty;

    [StringLength(400)]
    [Display(Name = "Mô tả")]
    public string? Description { get; set; }

    [StringLength(60)]
    [Display(Name = "Biểu tượng")]
    public string? IconClass { get; set; }

    [Display(Name = "Danh mục cha")]
    public int? ParentId { get; set; }

    [ForeignKey(nameof(ParentId))]
    public Category? Parent { get; set; }

    public ICollection<Category> Children { get; set; } = new List<Category>();

    /// <summary>Phân biệt nhóm hàng hoá và nhóm dịch vụ.</summary>
    [Display(Name = "Loại")]
    public CategoryKind Kind { get; set; } = CategoryKind.Product;

    [Display(Name = "Thứ tự")]
    public int DisplayOrder { get; set; }

    [Display(Name = "Hiển thị")]
    public bool IsActive { get; set; } = true;

    public ICollection<Product> Products { get; set; } = new List<Product>();
}

public enum CategoryKind
{
    [Display(Name = "Hàng hoá")]
    Product = 0,

    [Display(Name = "Dịch vụ")]
    Service = 1
}
