using System.ComponentModel.DataAnnotations;

namespace ToanTechWeb.Models.Entities;

/// <summary>
/// Lĩnh vực hoạt động của công ty (yêu cầu 1 của đề bài).
/// </summary>
public class BusinessField
{
    public int Id { get; set; }

    [Required(ErrorMessage = "Vui lòng nhập tên lĩnh vực")]
    [StringLength(150)]
    [Display(Name = "Tên lĩnh vực")]
    public string Name { get; set; } = string.Empty;

    [Required]
    [StringLength(170)]
    [Display(Name = "Đường dẫn tĩnh (slug)")]
    public string Slug { get; set; } = string.Empty;

    [StringLength(400)]
    [Display(Name = "Mô tả ngắn")]
    public string? Summary { get; set; }

    [Display(Name = "Nội dung chi tiết")]
    public string? Content { get; set; }

    [StringLength(255)]
    [Display(Name = "Ảnh đại diện")]
    public string? ImageUrl { get; set; }

    [StringLength(60)]
    [Display(Name = "Biểu tượng (Bootstrap Icon)")]
    public string? IconClass { get; set; }

    [Display(Name = "Thứ tự hiển thị")]
    public int DisplayOrder { get; set; }

    [Display(Name = "Hiển thị")]
    public bool IsActive { get; set; } = true;

    public DateTime CreatedAt { get; set; } = DateTime.Now;
}
