using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ToanTechWeb.Models.Entities;

/// <summary>Chuyên mục tin tức.</summary>
public class NewsCategory
{
    public int Id { get; set; }

    [Required(ErrorMessage = "Vui lòng nhập tên chuyên mục")]
    [StringLength(120)]
    [Display(Name = "Tên chuyên mục")]
    public string Name { get; set; } = string.Empty;

    [Required]
    [StringLength(140)]
    [Display(Name = "Slug")]
    public string Slug { get; set; } = string.Empty;

    [Display(Name = "Thứ tự")]
    public int DisplayOrder { get; set; }

    [Display(Name = "Hiển thị")]
    public bool IsActive { get; set; } = true;

    public ICollection<NewsArticle> Articles { get; set; } = new List<NewsArticle>();
}

/// <summary>
/// Bài viết tin tức về hoạt động của công ty (yêu cầu 4 của đề bài).
/// </summary>
public class NewsArticle
{
    public int Id { get; set; }

    [Required(ErrorMessage = "Vui lòng nhập tiêu đề")]
    [StringLength(250)]
    [Display(Name = "Tiêu đề")]
    public string Title { get; set; } = string.Empty;

    [Required]
    [StringLength(270)]
    [Display(Name = "Slug")]
    public string Slug { get; set; } = string.Empty;

    [Display(Name = "Chuyên mục")]
    [Range(1, int.MaxValue, ErrorMessage = "Vui lòng chọn chuyên mục")]
    public int NewsCategoryId { get; set; }

    [ForeignKey(nameof(NewsCategoryId))]
    public NewsCategory? NewsCategory { get; set; }

    [StringLength(500)]
    [Display(Name = "Tóm tắt")]
    public string? Summary { get; set; }

    /// <summary>Nội dung HTML, được HtmlSanitizer làm sạch trước khi lưu.</summary>
    [Required(ErrorMessage = "Vui lòng nhập nội dung bài viết")]
    [Display(Name = "Nội dung")]
    public string Content { get; set; } = string.Empty;

    [StringLength(255)]
    [Display(Name = "Ảnh minh hoạ")]
    public string? ImageUrl { get; set; }

    [StringLength(100)]
    [Display(Name = "Tác giả")]
    public string? Author { get; set; }

    [Display(Name = "Xuất bản")]
    public bool IsPublished { get; set; } = true;

    [Display(Name = "Nổi bật")]
    public bool IsFeatured { get; set; }

    [Display(Name = "Lượt xem")]
    public int ViewCount { get; set; }

    [Display(Name = "Ngày đăng")]
    public DateTime PublishedAt { get; set; } = DateTime.Now;

    public DateTime CreatedAt { get; set; } = DateTime.Now;
}
