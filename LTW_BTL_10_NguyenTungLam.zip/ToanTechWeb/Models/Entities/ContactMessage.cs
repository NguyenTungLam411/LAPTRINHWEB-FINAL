using System.ComponentModel.DataAnnotations;

namespace ToanTechWeb.Models.Entities;

/// <summary>Liên hệ / yêu cầu tư vấn do khách gửi từ trang Liên hệ.</summary>
public class ContactMessage
{
    public int Id { get; set; }

    [Required(ErrorMessage = "Vui lòng nhập họ tên")]
    [StringLength(100)]
    [Display(Name = "Họ và tên")]
    public string FullName { get; set; } = string.Empty;

    [Required(ErrorMessage = "Vui lòng nhập email")]
    [EmailAddress(ErrorMessage = "Email không hợp lệ")]
    [StringLength(150)]
    [Display(Name = "Email")]
    public string Email { get; set; } = string.Empty;

    [RegularExpression(@"^(0|\+84)[0-9]{9}$", ErrorMessage = "Số điện thoại không hợp lệ")]
    [StringLength(20)]
    [Display(Name = "Điện thoại")]
    public string? Phone { get; set; }

    [Required(ErrorMessage = "Vui lòng nhập tiêu đề")]
    [StringLength(200)]
    [Display(Name = "Tiêu đề")]
    public string Subject { get; set; } = string.Empty;

    [Required(ErrorMessage = "Vui lòng nhập nội dung")]
    [StringLength(2000, MinimumLength = 10, ErrorMessage = "Nội dung từ 10 đến 2000 ký tự")]
    [Display(Name = "Nội dung")]
    public string Message { get; set; } = string.Empty;

    [Display(Name = "Đã xử lý")]
    public bool IsHandled { get; set; }

    [Display(Name = "Ngày gửi")]
    public DateTime CreatedAt { get; set; } = DateTime.Now;
}
