using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Identity;

namespace ToanTechWeb.Models.Entities;

/// <summary>
/// Tài khoản người dùng, mở rộng từ IdentityUser của ASP.NET Core Identity.
/// Mật khẩu KHÔNG bao giờ được lưu dạng rõ - Identity băm bằng PBKDF2 (HMAC-SHA256, 100.000 vòng lặp).
/// </summary>
public class ApplicationUser : IdentityUser
{
    [Required(ErrorMessage = "Vui lòng nhập họ tên")]
    [StringLength(100, ErrorMessage = "Họ tên tối đa 100 ký tự")]
    [Display(Name = "Họ và tên")]
    public string FullName { get; set; } = string.Empty;

    [StringLength(250)]
    [Display(Name = "Địa chỉ")]
    public string? Address { get; set; }

    [Display(Name = "Ngày sinh")]
    [DataType(DataType.Date)]
    public DateTime? DateOfBirth { get; set; }

    [Display(Name = "Ngày tạo")]
    public DateTime CreatedAt { get; set; } = DateTime.Now;

    [Display(Name = "Đang hoạt động")]
    public bool IsActive { get; set; } = true;

    public ICollection<Order> Orders { get; set; } = new List<Order>();
}

/// <summary>Tên các vai trò dùng cho phân quyền. Dùng hằng số để tránh gõ sai chuỗi.</summary>
public static class RoleNames
{
    public const string Administrator = "Administrator";
    public const string Staff = "Staff";
    public const string Customer = "Customer";

    public static readonly string[] All = { Administrator, Staff, Customer };
}
