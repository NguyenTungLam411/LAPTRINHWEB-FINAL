namespace ToanTechWeb.Models.ViewModels;

/// <summary>Dữ liệu cho partial view phân trang dùng chung toàn site.</summary>
public class PagerModel
{
    public int PageIndex { get; set; }
    public int TotalPages { get; set; }
    public int TotalItems { get; set; }

    /// <summary>Action đích, mặc định là action hiện tại.</summary>
    public string Action { get; set; } = "Index";
    public string? Controller { get; set; }
    public string? Area { get; set; }

    /// <summary>Các tham số lọc cần giữ lại khi chuyển trang.</summary>
    public Dictionary<string, string?> RouteValues { get; set; } = new();

    public bool HasPrevious => PageIndex > 1;
    public bool HasNext => PageIndex < TotalPages;

    /// <summary>Dải số trang hiển thị, tối đa 5 nút quanh trang hiện tại.</summary>
    public IEnumerable<int> VisiblePages()
    {
        var start = Math.Max(1, PageIndex - 2);
        var end = Math.Min(TotalPages, start + 4);
        start = Math.Max(1, end - 4);

        for (var i = start; i <= end; i++) yield return i;
    }

    public Dictionary<string, string?> For(int page)
    {
        var values = new Dictionary<string, string?>(RouteValues) { ["page"] = page.ToString() };
        return values;
    }
}
