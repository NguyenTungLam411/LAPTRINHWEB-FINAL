using Microsoft.EntityFrameworkCore;

namespace ToanTechWeb.Models.ViewModels;

/// <summary>
/// Danh sách đã phân trang. Chỉ tải đúng số bản ghi của trang hiện tại
/// (Skip/Take dịch thành OFFSET ... FETCH NEXT trong SQL Server) nên không
/// phụ thuộc vào tổng số bản ghi trong bảng.
/// </summary>
public class PagedList<T> : List<T>
{
    public int PageIndex { get; }
    public int PageSize { get; }
    public int TotalItems { get; }
    public int TotalPages { get; }

    public bool HasPreviousPage => PageIndex > 1;
    public bool HasNextPage => PageIndex < TotalPages;

    public PagedList(IEnumerable<T> items, int totalItems, int pageIndex, int pageSize)
    {
        TotalItems = totalItems;
        PageSize = pageSize;
        PageIndex = pageIndex;
        TotalPages = pageSize > 0 ? (int)Math.Ceiling(totalItems / (double)pageSize) : 0;
        AddRange(items);
    }

    public static async Task<PagedList<T>> CreateAsync(IQueryable<T> source, int pageIndex, int pageSize)
    {
        if (pageIndex < 1) pageIndex = 1;
        if (pageSize < 1) pageSize = 12;

        var count = await source.CountAsync();
        var items = await source.Skip((pageIndex - 1) * pageSize).Take(pageSize).ToListAsync();
        return new PagedList<T>(items, count, pageIndex, pageSize);
    }
}
