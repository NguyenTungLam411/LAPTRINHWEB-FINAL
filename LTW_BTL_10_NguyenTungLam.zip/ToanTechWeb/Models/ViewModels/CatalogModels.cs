using ToanTechWeb.Models.Entities;

namespace ToanTechWeb.Models.ViewModels;

/// <summary>Dữ liệu cho trang chủ.</summary>
public class HomeViewModel
{
    public List<BusinessField> BusinessFields { get; set; } = new();
    public List<Product> FeaturedProducts { get; set; } = new();
    public List<Product> NewProducts { get; set; } = new();
    public List<Category> RootCategories { get; set; } = new();
    public List<NewsArticle> LatestNews { get; set; } = new();
}

/// <summary>Tham số lọc + kết quả cho trang danh sách sản phẩm.</summary>
public class ProductListViewModel
{
    public PagedList<Product>? Products { get; set; }
    public List<Category> Categories { get; set; } = new();
    public Category? CurrentCategory { get; set; }

    // Tham số lọc lấy từ query string
    public string? Keyword { get; set; }
    public int? CategoryId { get; set; }
    public decimal? MinPrice { get; set; }
    public decimal? MaxPrice { get; set; }
    public string? Brand { get; set; }
    public string SortBy { get; set; } = "newest";
    public int Page { get; set; } = 1;

    public List<string> AvailableBrands { get; set; } = new();

    /// <summary>Sinh lại query string để giữ bộ lọc khi chuyển trang.</summary>
    public Dictionary<string, string?> RouteValues(int page) => new()
    {
        ["keyword"] = Keyword,
        ["categoryId"] = CategoryId?.ToString(),
        ["minPrice"] = MinPrice?.ToString(),
        ["maxPrice"] = MaxPrice?.ToString(),
        ["brand"] = Brand,
        ["sortBy"] = SortBy,
        ["page"] = page.ToString()
    };
}

public class ProductDetailViewModel
{
    public Product Product { get; set; } = null!;
    public List<Product> RelatedProducts { get; set; } = new();
}

public class NewsListViewModel
{
    public PagedList<NewsArticle>? Articles { get; set; }
    public List<NewsCategory> Categories { get; set; } = new();
    public NewsCategory? CurrentCategory { get; set; }
    public List<NewsArticle> FeaturedArticles { get; set; } = new();
    public string? Keyword { get; set; }
    public int? CategoryId { get; set; }
}

public class NewsDetailViewModel
{
    public NewsArticle Article { get; set; } = null!;
    public List<NewsArticle> RelatedArticles { get; set; } = new();
}

/// <summary>Số liệu tổng hợp hiển thị trên Dashboard quản trị.</summary>
public class DashboardViewModel
{
    public int TotalProducts { get; set; }
    public int TotalOrders { get; set; }
    public int PendingOrders { get; set; }
    public int TotalCustomers { get; set; }
    public int TotalNews { get; set; }
    public int UnhandledContacts { get; set; }
    public decimal RevenueThisMonth { get; set; }
    public decimal RevenueTotal { get; set; }
    public List<Order> RecentOrders { get; set; } = new();
    public List<Product> LowStockProducts { get; set; } = new();

    /// <summary>Doanh thu 6 tháng gần nhất, dùng vẽ biểu đồ cột bằng Chart.js.</summary>
    public List<MonthlyRevenue> RevenueChart { get; set; } = new();
}

public class MonthlyRevenue
{
    public string Label { get; set; } = string.Empty;
    public decimal Amount { get; set; }
    public int OrderCount { get; set; }
}
