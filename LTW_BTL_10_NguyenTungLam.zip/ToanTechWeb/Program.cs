using System.Globalization;
using System.Threading.RateLimiting;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.EntityFrameworkCore;
using ToanTechWeb.Data;
using ToanTechWeb.Middleware;
using ToanTechWeb.Models.Entities;
using ToanTechWeb.Services;

var builder = WebApplication.CreateBuilder(args);

// ============================================================================
// 1. KẾT NỐI CSDL - Entity Framework Core + MS SQL Server
// ============================================================================
var connectionString = builder.Configuration.GetConnectionString("DefaultConnection")
    ?? throw new InvalidOperationException("Chưa cấu hình chuỗi kết nối 'DefaultConnection'.");

builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlServer(connectionString, sql => sql.EnableRetryOnFailure(3)));

// ============================================================================
// 2. XÁC THỰC & PHÂN QUYỀN - ASP.NET Core Identity
// ============================================================================
builder.Services
    .AddIdentity<ApplicationUser, IdentityRole>(options =>
    {
        // Chính sách mật khẩu mạnh
        options.Password.RequiredLength = 8;
        options.Password.RequireDigit = true;
        options.Password.RequireLowercase = true;
        options.Password.RequireUppercase = true;
        options.Password.RequireNonAlphanumeric = true;
        options.Password.RequiredUniqueChars = 1;

        // Khoá tài khoản 15 phút sau 5 lần sai mật khẩu -> chống dò mật khẩu (brute force)
        options.Lockout.MaxFailedAccessAttempts = 5;
        options.Lockout.DefaultLockoutTimeSpan = TimeSpan.FromMinutes(15);
        options.Lockout.AllowedForNewUsers = true;

        options.User.RequireUniqueEmail = true;
        options.SignIn.RequireConfirmedAccount = false;
    })
    .AddEntityFrameworkStores<ApplicationDbContext>()
    .AddDefaultTokenProviders();

builder.Services.ConfigureApplicationCookie(options =>
{
    options.LoginPath = "/Account/Login";
    options.LogoutPath = "/Account/Logout";
    options.AccessDeniedPath = "/Account/AccessDenied";
    options.ExpireTimeSpan = TimeSpan.FromHours(2);
    options.SlidingExpiration = true;

    options.Cookie.Name = "ToanTech.Auth";
    options.Cookie.HttpOnly = true;                                   // JavaScript không đọc được cookie
    options.Cookie.SameSite = SameSiteMode.Lax;                       // hạn chế gửi cookie cross-site (CSRF)
    options.Cookie.SecurePolicy = CookieSecurePolicy.SameAsRequest;
});

// Chính sách phân quyền theo vai trò
builder.Services.AddAuthorization(options =>
{
    options.AddPolicy("AdminOnly", p => p.RequireRole(RoleNames.Administrator));
    options.AddPolicy("AdminArea", p => p.RequireRole(RoleNames.Administrator, RoleNames.Staff));
});

// ============================================================================
// 3. SESSION (giỏ hàng) + CHỐNG CSRF
// ============================================================================
builder.Services.AddDistributedMemoryCache();
builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromMinutes(60);
    options.Cookie.Name = "ToanTech.Session";
    options.Cookie.HttpOnly = true;
    options.Cookie.IsEssential = true;
    options.Cookie.SameSite = SameSiteMode.Lax;
});

builder.Services.AddAntiforgery(options =>
{
    options.HeaderName = "RequestVerificationToken"; // để gọi được từ AJAX
    options.Cookie.Name = "ToanTech.Antiforgery";
    options.Cookie.HttpOnly = true;
    options.Cookie.SameSite = SameSiteMode.Strict;
});

// ============================================================================
// 4. GIỚI HẠN TẦN SUẤT (Rate limiting) - chống spam đăng nhập / gửi liên hệ
// ============================================================================
builder.Services.AddRateLimiter(options =>
{
    options.RejectionStatusCode = StatusCodes.Status429TooManyRequests;

    options.AddPolicy("AuthPolicy", httpContext =>
        RateLimitPartition.GetFixedWindowLimiter(
            partitionKey: httpContext.Connection.RemoteIpAddress?.ToString() ?? "unknown",
            factory: _ => new FixedWindowRateLimiterOptions
            {
                PermitLimit = 10,
                Window = TimeSpan.FromMinutes(1),
                QueueLimit = 0
            }));

    options.AddPolicy("ContactPolicy", httpContext =>
        RateLimitPartition.GetFixedWindowLimiter(
            partitionKey: httpContext.Connection.RemoteIpAddress?.ToString() ?? "unknown",
            factory: _ => new FixedWindowRateLimiterOptions
            {
                PermitLimit = 3,
                Window = TimeSpan.FromMinutes(5),
                QueueLimit = 0
            }));
});

// ============================================================================
// 5. MVC + các dịch vụ nghiệp vụ
// ============================================================================
builder.Services.AddControllersWithViews(options =>
{
    // Bắt buộc kiểm tra anti-forgery token cho MỌI request ghi dữ liệu
    // (POST/PUT/DELETE), kể cả khi lập trình viên quên gắn [ValidateAntiForgeryToken].
    options.Filters.Add(new Microsoft.AspNetCore.Mvc.AutoValidateAntiforgeryTokenAttribute());
});

builder.Services.AddHttpContextAccessor();
builder.Services.AddScoped<ICartService, CartService>();
builder.Services.AddScoped<IFileUploadService, FileUploadService>();
builder.Services.AddSingleton<IHtmlSanitizerService, HtmlSanitizerService>();

var app = builder.Build();

// Định dạng số/tiền theo chuẩn Việt Nam trên toàn ứng dụng.
var vietnamese = new CultureInfo("vi-VN");
CultureInfo.DefaultThreadCurrentCulture = vietnamese;
CultureInfo.DefaultThreadCurrentUICulture = vietnamese;
app.UseRequestLocalization(new RequestLocalizationOptions
{
    DefaultRequestCulture = new Microsoft.AspNetCore.Localization.RequestCulture(vietnamese),
    SupportedCultures = new[] { vietnamese },
    SupportedUICultures = new[] { vietnamese }
});

// ============================================================================
// 6. PIPELINE XỬ LÝ REQUEST (thứ tự rất quan trọng)
// ============================================================================
if (app.Environment.IsDevelopment())
{
    app.UseDeveloperExceptionPage();
}
else
{
    // Trang lỗi thân thiện - KHÔNG lộ stack trace ra ngoài (chống lộ thông tin hệ thống).
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

// Hiển thị trang 404/403 tuỳ biến thay vì trang trắng của máy chủ.
app.UseStatusCodePagesWithReExecute("/Home/StatusCode", "?code={0}");

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseSecurityHeaders();

app.UseRouting();
app.UseRateLimiter();
app.UseSession();

app.UseAuthentication();  // "Bạn là ai?"
app.UseAuthorization();   // "Bạn được làm gì?"

// ============================================================================
// 7. ĐỊNH TUYẾN
// ============================================================================
app.MapControllerRoute(
    name: "areas",
    pattern: "{area:exists}/{controller=Dashboard}/{action=Index}/{id?}");

app.MapControllerRoute(
    name: "product-detail",
    pattern: "san-pham/{slug}",
    defaults: new { controller = "Product", action = "Details" });

app.MapControllerRoute(
    name: "news-detail",
    pattern: "tin-tuc/{slug}",
    defaults: new { controller = "News", action = "Details" });

app.MapControllerRoute(
    name: "field-detail",
    pattern: "linh-vuc/{slug}",
    defaults: new { controller = "BusinessField", action = "Details" });

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

// ============================================================================
// 8. TẠO CSDL + NẠP DỮ LIỆU MẪU KHI KHỞI ĐỘNG
// ============================================================================
await using (var scope = app.Services.CreateAsyncScope())
{
    var services = scope.ServiceProvider;
    var logger = services.GetRequiredService<ILogger<Program>>();
    try
    {
        var context = services.GetRequiredService<ApplicationDbContext>();
        await context.Database.MigrateAsync();
        await DbSeeder.SeedAsync(services);
        logger.LogInformation("Khởi tạo CSDL và dữ liệu mẫu thành công.");
    }
    catch (Exception ex)
    {
        logger.LogError(ex, "Lỗi khi khởi tạo CSDL.");
        throw;
    }
}

app.Run();
