/* ==========================================================================
   TOANTECH - Mã lệnh phía Client (Client side)
   Gồm: thêm giỏ hàng bằng AJAX, gợi ý tìm kiếm, cập nhật số lượng,
        kiểm tra dữ liệu form phía trình duyệt, nút lên đầu trang.
   ========================================================================== */
(function () {
    'use strict';

    // ---------------------------------------------------------------- Tiện ích
    /** Lấy anti-forgery token do máy chủ sinh ra, để gửi kèm mọi request AJAX POST. */
    function getAntiForgeryToken() {
        var input = document.querySelector('input[name="__RequestVerificationToken"]');
        return input ? input.value : '';
    }

    /** Định dạng số theo kiểu Việt Nam: 1234567 -> "1.234.567" */
    function formatMoney(value) {
        return Number(value).toLocaleString('vi-VN');
    }

    /** Hiển thị thông báo nổi ở góc phải màn hình. */
    function showToast(message, type) {
        var container = document.getElementById('toastContainer');
        if (!container) {
            container = document.createElement('div');
            container.id = 'toastContainer';
            container.className = 'toast-container position-fixed top-0 end-0 p-3';
            container.style.zIndex = '1090';
            document.body.appendChild(container);
        }

        var bg = type === 'error' ? 'bg-danger' : 'bg-success';
        var icon = type === 'error' ? 'bi-exclamation-octagon-fill' : 'bi-check-circle-fill';

        var el = document.createElement('div');
        el.className = 'toast align-items-center text-white ' + bg + ' border-0';
        el.setAttribute('role', 'alert');
        el.innerHTML =
            '<div class="d-flex">' +
            '  <div class="toast-body"><i class="bi ' + icon + ' me-2"></i><span></span></div>' +
            '  <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>' +
            '</div>';
        // Dùng textContent thay vì innerHTML để nội dung động không thể chèn mã HTML (chống XSS phía client).
        el.querySelector('.toast-body span').textContent = message;

        container.appendChild(el);
        var toast = new bootstrap.Toast(el, { delay: 3500 });
        toast.show();
        el.addEventListener('hidden.bs.toast', function () { el.remove(); });
    }

    function updateCartBadge(count) {
        var badge = document.getElementById('cartBadge');
        if (!badge) return;
        badge.textContent = count;
        badge.classList.toggle('d-none', count === 0);
    }

    // ------------------------------------------------- Thêm sản phẩm vào giỏ
    document.addEventListener('click', function (e) {
        var btn = e.target.closest('.btn-add-cart');
        if (!btn) return;

        e.preventDefault();

        var productId = btn.dataset.productId;
        var qtyInput = document.getElementById('detailQuantity');
        var quantity = qtyInput ? parseInt(qtyInput.value, 10) || 1 : 1;

        var original = btn.innerHTML;
        btn.disabled = true;
        btn.innerHTML = '<span class="spinner-border spinner-border-sm"></span>';

        var body = new URLSearchParams();
        body.append('productId', productId);
        body.append('quantity', quantity);

        fetch('/Cart/Add', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'RequestVerificationToken': getAntiForgeryToken()
            },
            body: body.toString()
        })
            .then(function (r) { return r.json(); })
            .then(function (data) {
                if (data.success) {
                    updateCartBadge(data.cartCount);
                    showToast(data.message, 'success');
                } else {
                    showToast(data.message, 'error');
                }
            })
            .catch(function () {
                showToast('Không kết nối được tới máy chủ. Vui lòng thử lại.', 'error');
            })
            .finally(function () {
                btn.disabled = false;
                btn.innerHTML = original;
            });
    });

    // ------------------------------------------- Cập nhật số lượng trong giỏ
    document.addEventListener('click', function (e) {
        var btn = e.target.closest('.btn-qty');
        if (!btn) return;

        var input = document.querySelector('.qty-input[data-product-id="' + btn.dataset.productId + '"]');
        if (!input) return;

        var value = parseInt(input.value, 10) || 1;
        value += (btn.dataset.step === 'up' ? 1 : -1);
        if (value < 1) value = 1;
        input.value = value;
        syncCartLine(btn.dataset.productId, value);
    });

    document.addEventListener('change', function (e) {
        if (!e.target.classList.contains('qty-input')) return;

        var value = parseInt(e.target.value, 10);
        if (isNaN(value) || value < 1) { value = 1; e.target.value = 1; }
        syncCartLine(e.target.dataset.productId, value);
    });

    function syncCartLine(productId, quantity) {
        var body = new URLSearchParams();
        body.append('productId', productId);
        body.append('quantity', quantity);

        fetch('/Cart/Update', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'RequestVerificationToken': getAntiForgeryToken()
            },
            body: body.toString()
        })
            .then(function (r) { return r.json(); })
            .then(function (data) {
                if (!data.success) {
                    showToast(data.message, 'error');
                    window.location.reload();
                    return;
                }

                var line = document.querySelector('.line-total[data-product-id="' + productId + '"]');
                if (line) line.textContent = data.lineTotal + ' đ';

                setText('cartSubTotal', data.subTotal + ' đ');
                setText('cartShipping', data.shippingFee === '0' ? 'Miễn phí' : data.shippingFee + ' đ');
                setText('cartTotal', data.total + ' đ');
                updateCartBadge(data.cartCount);
            });
    }

    function setText(id, text) {
        var el = document.getElementById(id);
        if (el) el.textContent = text;
    }

    // ------------------------------------------------------ Gợi ý tìm kiếm
    var searchInput = document.getElementById('searchInput');
    var suggestBox = document.getElementById('searchSuggest');

    if (searchInput && suggestBox) {
        var timer = null;

        searchInput.addEventListener('input', function () {
            var term = searchInput.value.trim();
            clearTimeout(timer);

            if (term.length < 2) { suggestBox.style.display = 'none'; return; }

            // Chờ 300ms sau lần gõ cuối mới gọi máy chủ, tránh gửi quá nhiều request.
            timer = setTimeout(function () {
                fetch('/Product/Suggest?term=' + encodeURIComponent(term))
                    .then(function (r) { return r.json(); })
                    .then(function (items) {
                        suggestBox.innerHTML = '';

                        if (!items.length) { suggestBox.style.display = 'none'; return; }

                        items.forEach(function (item) {
                            var a = document.createElement('a');
                            a.href = '/san-pham/' + item.slug;

                            var img = document.createElement('img');
                            img.src = item.imageUrl || '/images/products/no-image.svg';
                            img.alt = '';

                            var wrap = document.createElement('div');
                            var name = document.createElement('div');
                            name.className = 'fw-semibold';
                            name.textContent = item.name;          // textContent -> an toàn với XSS
                            var price = document.createElement('div');
                            price.className = 'text-danger small';
                            price.textContent = formatMoney(item.price) + ' đ';

                            wrap.appendChild(name);
                            wrap.appendChild(price);
                            a.appendChild(img);
                            a.appendChild(wrap);
                            suggestBox.appendChild(a);
                        });

                        suggestBox.style.display = 'block';
                    });
            }, 300);
        });

        document.addEventListener('click', function (e) {
            if (!suggestBox.contains(e.target) && e.target !== searchInput) {
                suggestBox.style.display = 'none';
            }
        });
    }

    // ------------------------------------------------- Nút lên đầu trang
    var backToTop = document.getElementById('backToTop');
    if (backToTop) {
        window.addEventListener('scroll', function () {
            backToTop.classList.toggle('show', window.scrollY > 400);
        });
        backToTop.addEventListener('click', function () {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    // ------------------------------ Kiểm tra dữ liệu trước khi gửi form
    // Lưu ý: đây chỉ là lớp kiểm tra cho thân thiện người dùng.
    // Máy chủ VẪN kiểm tra lại toàn bộ bằng ModelState (xem các Controller).
    document.querySelectorAll('form[data-validate="true"]').forEach(function (form) {
        form.addEventListener('submit', function (e) {
            var valid = true;

            form.querySelectorAll('[data-rule]').forEach(function (field) {
                var rule = field.dataset.rule;
                var value = field.value.trim();
                var ok = true;

                if (rule === 'required') ok = value.length > 0;
                if (rule === 'phone') ok = /^(0|\+84)[0-9]{9}$/.test(value);
                if (rule === 'email') ok = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);

                field.classList.toggle('is-invalid', !ok);
                if (!ok) valid = false;
            });

            if (!valid) { e.preventDefault(); e.stopPropagation(); }
        });
    });

    // --------------------------------- Xác nhận trước thao tác xoá
    document.addEventListener('submit', function (e) {
        var form = e.target;
        if (!form.hasAttribute('data-confirm')) return;
        if (!window.confirm(form.getAttribute('data-confirm'))) e.preventDefault();
    });

})();
