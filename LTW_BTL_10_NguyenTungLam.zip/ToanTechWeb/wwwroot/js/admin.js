/* Mã lệnh phía client cho khu vực quản trị. */
(function () {
    'use strict';

    // ------------------------------------------- Đóng/mở menu trên điện thoại
    var toggle = document.getElementById('sidebarToggle');
    var sidebar = document.getElementById('adminSidebar');
    var backdrop = null;

    function closeSidebar() {
        sidebar.classList.remove('show');
        if (backdrop) { backdrop.remove(); backdrop = null; }
    }

    if (toggle && sidebar) {
        toggle.addEventListener('click', function () {
            sidebar.classList.add('show');
            backdrop = document.createElement('div');
            backdrop.className = 'sidebar-backdrop';
            backdrop.addEventListener('click', closeSidebar);
            document.body.appendChild(backdrop);
        });
    }

    // ------------------------------------------ Xác nhận trước khi xoá
    document.addEventListener('submit', function (e) {
        var form = e.target;
        if (!form.hasAttribute('data-confirm')) return;
        if (!window.confirm(form.getAttribute('data-confirm'))) e.preventDefault();
    });

    // ------------------------------------ Xem trước ảnh khi chọn tệp
    document.querySelectorAll('input[type="file"][data-preview]').forEach(function (input) {
        input.addEventListener('change', function () {
            var target = document.getElementById(input.dataset.preview);
            if (!target || !input.files || !input.files[0]) return;

            var file = input.files[0];
            if (file.size > 4 * 1024 * 1024) {
                alert('Ảnh vượt quá 4 MB. Vui lòng chọn tệp nhỏ hơn.');
                input.value = '';
                return;
            }

            var reader = new FileReader();
            reader.onload = function (ev) { target.src = ev.target.result; };
            reader.readAsDataURL(file);
        });
    });

    // -------------------------- Tự sinh mã sản phẩm gợi ý từ tên (nếu trống)
    var nameField = document.getElementById('Name');
    var skuField = document.getElementById('Sku');
    if (nameField && skuField && skuField.dataset.autofill === 'true') {
        nameField.addEventListener('blur', function () {
            if (skuField.value.trim() !== '') return;
            var words = nameField.value.trim().split(/\s+/).slice(0, 3);
            skuField.value = words.map(function (w) { return w.substring(0, 2).toUpperCase(); }).join('')
                + '-' + Math.floor(Math.random() * 9000 + 1000);
        });
    }

    // ---------------------------------------- Bật/tắt trạng thái kinh doanh
    document.querySelectorAll('.toggle-active').forEach(function (el) {
        el.addEventListener('change', function () {
            var token = document.querySelector('input[name="__RequestVerificationToken"]');
            var body = new URLSearchParams();
            body.append('id', el.dataset.id);

            fetch('/Admin/Products/ToggleActive', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'RequestVerificationToken': token ? token.value : ''
                },
                body: body.toString()
            })
                .then(function (r) { return r.json(); })
                .then(function (data) {
                    if (!data.success) { el.checked = !el.checked; }
                })
                .catch(function () { el.checked = !el.checked; });
        });
    });

})();
