using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using ToanTechWeb.Models.Entities;

namespace ToanTechWeb.Data;

/// <summary>
/// Nạp dữ liệu mẫu lần đầu chạy. Mỗi khối đều kiểm tra "đã có dữ liệu chưa"
/// nên chạy lại nhiều lần cũng không sinh bản ghi trùng.
/// </summary>
public static class DbSeeder
{
    public static async Task SeedAsync(IServiceProvider services)
    {
        var context = services.GetRequiredService<ApplicationDbContext>();
        var userManager = services.GetRequiredService<UserManager<ApplicationUser>>();
        var roleManager = services.GetRequiredService<RoleManager<IdentityRole>>();
        var configuration = services.GetRequiredService<IConfiguration>();

        await SeedRolesAndUsersAsync(userManager, roleManager, configuration);
        await SeedBusinessFieldsAsync(context);
        await SeedCategoriesAsync(context);
        await SeedProductsAsync(context);
        await SeedNewsAsync(context);
        await SeedSampleOrdersAsync(context, userManager, configuration);
    }

    // ------------------------------------------------------------------ Roles
    private static async Task SeedRolesAndUsersAsync(
        UserManager<ApplicationUser> userManager,
        RoleManager<IdentityRole> roleManager,
        IConfiguration configuration)
    {
        foreach (var role in RoleNames.All)
        {
            if (!await roleManager.RoleExistsAsync(role))
                await roleManager.CreateAsync(new IdentityRole(role));
        }

        await CreateUserAsync(userManager, configuration["SeedAccounts:AdminEmail"]!,
            configuration["SeedAccounts:AdminPassword"]!, "Lưu Đức Toàn",
            "0912345678", "Số 96 Định Công, Hoàng Mai, Hà Nội", RoleNames.Administrator);

        await CreateUserAsync(userManager, configuration["SeedAccounts:StaffEmail"]!,
            configuration["SeedAccounts:StaffPassword"]!, "Trần Thị Nhân Viên",
            "0987654321", "Số 12 Trần Duy Hưng, Cầu Giấy, Hà Nội", RoleNames.Staff);

        await CreateUserAsync(userManager, configuration["SeedAccounts:CustomerEmail"]!,
            configuration["SeedAccounts:CustomerPassword"]!, "Nguyễn Văn Khách",
            "0901234567", "Số 5 Lê Duẩn, Hoàn Kiếm, Hà Nội", RoleNames.Customer);
    }

    private static async Task CreateUserAsync(
        UserManager<ApplicationUser> userManager,
        string email, string password, string fullName,
        string phone, string address, string role)
    {
        if (await userManager.FindByEmailAsync(email) is not null) return;

        var user = new ApplicationUser
        {
            UserName = email,
            Email = email,
            EmailConfirmed = true,
            FullName = fullName,
            PhoneNumber = phone,
            Address = address,
            CreatedAt = DateTime.Now
        };

        var result = await userManager.CreateAsync(user, password);
        if (result.Succeeded)
            await userManager.AddToRoleAsync(user, role);
    }

    // --------------------------------------------------------- Business fields
    private static async Task SeedBusinessFieldsAsync(ApplicationDbContext context)
    {
        if (await context.BusinessFields.AnyAsync()) return;

        context.BusinessFields.AddRange(
            new BusinessField
            {
                Name = "Phân phối thiết bị công nghệ",
                Slug = "phan-phoi-thiet-bi-cong-nghe",
                IconClass = "bi-laptop",
                DisplayOrder = 1,
                Summary = "Nhà phân phối uỷ quyền của Dell, HP, Lenovo, Asus, Samsung tại thị trường miền Bắc.",
                Content = "<p>TOANTECH là nhà phân phối uỷ quyền chính thức của nhiều thương hiệu công nghệ hàng đầu thế giới. " +
                          "Chúng tôi cung cấp máy tính xách tay, máy tính để bàn, màn hình, thiết bị mạng và phụ kiện chính hãng " +
                          "với chế độ bảo hành đầy đủ theo tiêu chuẩn của hãng.</p>" +
                          "<h3>Cam kết của chúng tôi</h3>" +
                          "<ul><li>100% hàng chính hãng, đầy đủ hoá đơn VAT</li>" +
                          "<li>Bảo hành theo tiêu chuẩn của nhà sản xuất</li>" +
                          "<li>Giá bán cạnh tranh nhờ nhập khẩu trực tiếp</li>" +
                          "<li>Giao hàng toàn quốc trong 24 - 72 giờ</li></ul>",
                ImageUrl = "/images/fields/phan-phoi.svg"
            },
            new BusinessField
            {
                Name = "Giải pháp hạ tầng công nghệ thông tin",
                Slug = "giai-phap-ha-tang-cntt",
                IconClass = "bi-hdd-network",
                DisplayOrder = 2,
                Summary = "Tư vấn, thiết kế và triển khai hệ thống mạng, máy chủ, lưu trữ cho doanh nghiệp.",
                Content = "<p>Đội ngũ kỹ sư được chứng nhận quốc tế của TOANTECH cung cấp trọn gói giải pháp hạ tầng " +
                          "công nghệ thông tin cho doanh nghiệp vừa và lớn.</p>" +
                          "<h3>Dịch vụ bao gồm</h3>" +
                          "<ul><li>Khảo sát và thiết kế hệ thống mạng LAN/WAN</li>" +
                          "<li>Triển khai máy chủ, ảo hoá, sao lưu và phục hồi dữ liệu</li>" +
                          "<li>Xây dựng hệ thống camera giám sát, kiểm soát ra vào</li>" +
                          "<li>Bảo trì định kỳ theo hợp đồng năm</li></ul>",
                ImageUrl = "/images/fields/ha-tang.svg"
            },
            new BusinessField
            {
                Name = "Dịch vụ bảo hành - sửa chữa",
                Slug = "dich-vu-bao-hanh-sua-chua",
                IconClass = "bi-tools",
                DisplayOrder = 3,
                Summary = "Trung tâm bảo hành uỷ quyền với kỹ thuật viên giàu kinh nghiệm, linh kiện chính hãng.",
                Content = "<p>Trung tâm dịch vụ của TOANTECH tiếp nhận bảo hành và sửa chữa mọi thiết bị công nghệ, " +
                          "kể cả sản phẩm không mua tại công ty.</p>" +
                          "<h3>Quy trình 4 bước</h3>" +
                          "<ol><li>Tiếp nhận và kiểm tra tình trạng máy</li>" +
                          "<li>Báo giá minh bạch trước khi sửa chữa</li>" +
                          "<li>Thực hiện sửa chữa, thay thế linh kiện chính hãng</li>" +
                          "<li>Bàn giao, bảo hành dịch vụ tối thiểu 3 tháng</li></ol>",
                ImageUrl = "/images/fields/bao-hanh.svg"
            },
            new BusinessField
            {
                Name = "Phát triển phần mềm theo yêu cầu",
                Slug = "phat-trien-phan-mem-theo-yeu-cau",
                IconClass = "bi-code-slash",
                DisplayOrder = 4,
                Summary = "Xây dựng website, ứng dụng quản lý và hệ thống thương mại điện tử cho doanh nghiệp.",
                Content = "<p>TOANTECH nhận phân tích, thiết kế và phát triển phần mềm theo đặc thù nghiệp vụ của " +
                          "từng khách hàng, trên nền tảng ASP.NET Core và MS SQL Server.</p>" +
                          "<h3>Sản phẩm tiêu biểu</h3>" +
                          "<ul><li>Website giới thiệu doanh nghiệp và thương mại điện tử</li>" +
                          "<li>Phần mềm quản lý kho, bán hàng, nhân sự</li>" +
                          "<li>Tích hợp cổng thanh toán và hoá đơn điện tử</li></ul>",
                ImageUrl = "/images/fields/phan-mem.svg"
            });

        await context.SaveChangesAsync();
    }

    // ------------------------------------------------------------- Categories
    private static async Task SeedCategoriesAsync(ApplicationDbContext context)
    {
        if (await context.Categories.AnyAsync()) return;

        // --- Cấp 1 ---
        var laptop = new Category { Name = "Máy tính xách tay", Slug = "may-tinh-xach-tay", IconClass = "bi-laptop", DisplayOrder = 1, Description = "Laptop văn phòng, đồ hoạ và gaming từ các thương hiệu lớn." };
        var pc = new Category { Name = "Máy tính để bàn", Slug = "may-tinh-de-ban", IconClass = "bi-pc-display", DisplayOrder = 2, Description = "PC nguyên bộ và máy trạm cho doanh nghiệp." };
        var phone = new Category { Name = "Điện thoại - Máy tính bảng", Slug = "dien-thoai-may-tinh-bang", IconClass = "bi-phone", DisplayOrder = 3, Description = "Điện thoại thông minh và máy tính bảng chính hãng." };
        var accessory = new Category { Name = "Linh kiện - Phụ kiện", Slug = "linh-kien-phu-kien", IconClass = "bi-usb-drive", DisplayOrder = 4, Description = "Bàn phím, chuột, tai nghe, ổ cứng và các phụ kiện khác." };
        var network = new Category { Name = "Thiết bị mạng - Văn phòng", Slug = "thiet-bi-mang-van-phong", IconClass = "bi-router", DisplayOrder = 5, Description = "Router, switch, máy in, camera giám sát." };
        var service = new Category { Name = "Dịch vụ công nghệ", Slug = "dich-vu-cong-nghe", IconClass = "bi-tools", DisplayOrder = 6, Kind = CategoryKind.Service, Description = "Các gói dịch vụ kỹ thuật do TOANTECH cung cấp." };

        context.Categories.AddRange(laptop, pc, phone, accessory, network, service);
        await context.SaveChangesAsync();

        // --- Cấp 2 ---
        context.Categories.AddRange(
            new Category { Name = "Laptop văn phòng", Slug = "laptop-van-phong", ParentId = laptop.Id, DisplayOrder = 1 },
            new Category { Name = "Laptop gaming", Slug = "laptop-gaming", ParentId = laptop.Id, DisplayOrder = 2 },
            new Category { Name = "Laptop đồ hoạ - kỹ thuật", Slug = "laptop-do-hoa-ky-thuat", ParentId = laptop.Id, DisplayOrder = 3 },
            new Category { Name = "PC đồng bộ", Slug = "pc-dong-bo", ParentId = pc.Id, DisplayOrder = 1 },
            new Category { Name = "Màn hình máy tính", Slug = "man-hinh-may-tinh", ParentId = pc.Id, DisplayOrder = 2 },
            new Category { Name = "Điện thoại thông minh", Slug = "dien-thoai-thong-minh", ParentId = phone.Id, DisplayOrder = 1 },
            new Category { Name = "Máy tính bảng", Slug = "may-tinh-bang", ParentId = phone.Id, DisplayOrder = 2 },
            new Category { Name = "Bàn phím - Chuột", Slug = "ban-phim-chuot", ParentId = accessory.Id, DisplayOrder = 1 },
            new Category { Name = "Tai nghe - Loa", Slug = "tai-nghe-loa", ParentId = accessory.Id, DisplayOrder = 2 },
            new Category { Name = "Ổ cứng - Bộ nhớ", Slug = "o-cung-bo-nho", ParentId = accessory.Id, DisplayOrder = 3 },
            new Category { Name = "Router - Switch", Slug = "router-switch", ParentId = network.Id, DisplayOrder = 1 },
            new Category { Name = "Máy in - Máy quét", Slug = "may-in-may-quet", ParentId = network.Id, DisplayOrder = 2 },
            new Category { Name = "Camera giám sát", Slug = "camera-giam-sat", ParentId = network.Id, DisplayOrder = 3 },
            new Category { Name = "Bảo trì hệ thống", Slug = "bao-tri-he-thong", ParentId = service.Id, Kind = CategoryKind.Service, DisplayOrder = 1 },
            new Category { Name = "Thiết kế website", Slug = "thiet-ke-website", ParentId = service.Id, Kind = CategoryKind.Service, DisplayOrder = 2 });

        await context.SaveChangesAsync();
    }

    // --------------------------------------------------------------- Products
    private static async Task SeedProductsAsync(ApplicationDbContext context)
    {
        if (await context.Products.AnyAsync()) return;

        var categories = await context.Categories.ToDictionaryAsync(c => c.Slug, c => c.Id);
        int Cat(string slug) => categories[slug];

        var products = new List<Product>
        {
            New("LTP-001", "Laptop Dell Inspiron 15 3520 i5-1235U 16GB 512GB", "laptop-van-phong", "Dell", 16990000, 18990000, 25, "laptop-1",
                "Màn hình 15.6\" FHD, chip Intel Core i5 thế hệ 12, RAM 16GB, SSD 512GB - lựa chọn cân bằng cho công việc văn phòng.",
                "<p>Dell Inspiron 15 3520 là mẫu laptop văn phòng bán chạy nhất của Dell trong phân khúc tầm trung.</p><h3>Thông số kỹ thuật</h3><ul><li>CPU: Intel Core i5-1235U (10 nhân, 12 luồng)</li><li>RAM: 16GB DDR4 3200MHz, nâng cấp tối đa 32GB</li><li>Ổ cứng: SSD NVMe 512GB</li><li>Màn hình: 15.6 inch Full HD 120Hz</li><li>Pin: 3 cell 41WHr, sạc nhanh ExpressCharge</li><li>Khối lượng: 1.65 kg</li></ul><p>Bảo hành chính hãng 12 tháng tại trung tâm của Dell Việt Nam.</p>", true),
            New("LTP-002", "Laptop HP Pavilion 14-dv2073TU i5-1235U 8GB 256GB", "laptop-van-phong", "HP", 15490000, 17290000, 18, "laptop-2",
                "Thiết kế mỏng nhẹ 1.41kg, màn hình 14\" IPS, phù hợp nhân viên văn phòng thường xuyên di chuyển.",
                "<p>HP Pavilion 14 mang thiết kế kim loại sang trọng trong thân máy chỉ 1.41 kg.</p><h3>Thông số kỹ thuật</h3><ul><li>CPU: Intel Core i5-1235U</li><li>RAM: 8GB DDR4, 1 khe trống để nâng cấp</li><li>Ổ cứng: SSD NVMe 256GB</li><li>Màn hình: 14 inch FHD IPS chống chói</li><li>Cổng kết nối: USB-C, 2x USB-A, HDMI 2.1</li></ul>", false),
            New("LTP-003", "Laptop Gaming Asus TUF F15 i7-12700H RTX 4060", "laptop-gaming", "Asus", 32990000, 35990000, 12, "laptop-3",
                "Card đồ hoạ RTX 4060 8GB, màn hình 144Hz, chuẩn quân đội MIL-STD-810H.",
                "<p>Asus TUF Gaming F15 là chiến binh bền bỉ dành cho game thủ và người làm đồ hoạ.</p><h3>Thông số kỹ thuật</h3><ul><li>CPU: Intel Core i7-12700H (14 nhân, 20 luồng)</li><li>GPU: NVIDIA GeForce RTX 4060 8GB GDDR6</li><li>RAM: 16GB DDR5 4800MHz</li><li>Ổ cứng: SSD NVMe PCIe 4.0 512GB</li><li>Màn hình: 15.6 inch FHD 144Hz, phủ 100% sRGB</li><li>Tản nhiệt: 2 quạt Arc Flow, 4 ống đồng</li></ul>", true),
            New("LTP-004", "Laptop Lenovo LOQ 15IRH8 i5-12450HX RTX 3050", "laptop-gaming", "Lenovo", 21990000, 23990000, 9, "laptop-4",
                "Laptop gaming giá tốt với RTX 3050 6GB và màn hình 144Hz.",
                "<p>Lenovo LOQ là dòng gaming phổ thông mới của Lenovo, kế thừa thiết kế tản nhiệt từ dòng Legion.</p><h3>Thông số kỹ thuật</h3><ul><li>CPU: Intel Core i5-12450HX</li><li>GPU: NVIDIA RTX 3050 6GB</li><li>RAM: 16GB DDR5</li><li>Màn hình: 15.6 inch FHD 144Hz</li></ul>", false),
            New("LTP-005", "Laptop Dell Precision 3581 i7-13700H RTX A500 Workstation", "laptop-do-hoa-ky-thuat", "Dell", 45990000, null, 6, "laptop-5",
                "Máy trạm di động đạt chứng chỉ ISV cho AutoCAD, SolidWorks, Revit.",
                "<p>Dell Precision 3581 được chứng nhận tương thích bởi Autodesk, Dassault và Siemens.</p><h3>Thông số kỹ thuật</h3><ul><li>CPU: Intel Core i7-13700H</li><li>GPU: NVIDIA RTX A500 4GB (chuẩn đồ hoạ chuyên nghiệp)</li><li>RAM: 32GB DDR5 ECC</li><li>Ổ cứng: SSD NVMe 1TB</li><li>Màn hình: 15.6 inch FHD+ 400nits</li></ul>", true),
            New("LTP-006", "MacBook Air M2 13 inch 8GB 256GB", "laptop-do-hoa-ky-thuat", "Apple", 24990000, 27990000, 14, "laptop-6",
                "Chip Apple M2, màn hình Liquid Retina, thời lượng pin tới 18 giờ.",
                "<p>MacBook Air M2 kết hợp hiệu năng mạnh mẽ với thiết kế mỏng nhẹ chỉ 1.24 kg.</p><h3>Thông số kỹ thuật</h3><ul><li>Chip: Apple M2 8 nhân CPU, 8 nhân GPU</li><li>RAM: 8GB bộ nhớ hợp nhất</li><li>Ổ cứng: SSD 256GB</li><li>Màn hình: 13.6 inch Liquid Retina 500 nits</li><li>Pin: tới 18 giờ xem video</li></ul>", true),

            New("PCD-001", "PC Đồng bộ Dell OptiPlex 7010 SFF i5-13500 8GB 256GB", "pc-dong-bo", "Dell", 17990000, 19490000, 20, "pc-1",
                "Máy tính để bàn nhỏ gọn cho doanh nghiệp, bảo hành 3 năm tại chỗ.",
                "<p>Dell OptiPlex 7010 SFF phù hợp triển khai đồng loạt cho văn phòng nhờ độ ổn định cao.</p><h3>Thông số kỹ thuật</h3><ul><li>CPU: Intel Core i5-13500 (14 nhân)</li><li>RAM: 8GB DDR4, hỗ trợ tối đa 64GB</li><li>Ổ cứng: SSD NVMe 256GB</li><li>Bảo hành: 3 năm ProSupport tại chỗ</li></ul>", false),
            New("PCD-002", "PC Gaming TOANTECH i5-13400F | RTX 4060 | 16GB", "pc-dong-bo", "TOANTECH", 23490000, 25990000, 8, "pc-2",
                "Bộ máy chơi game do TOANTECH lắp ráp, đã cài sẵn Windows và driver.",
                "<p>Cấu hình được kỹ thuật viên TOANTECH tối ưu để chơi tốt các tựa game phổ biến ở độ phân giải 2K.</p><h3>Cấu hình</h3><ul><li>CPU: Intel Core i5-13400F</li><li>Mainboard: ASUS PRIME B760M-K</li><li>VGA: RTX 4060 8GB</li><li>RAM: 16GB DDR4 3200MHz (2x8)</li><li>SSD: 500GB NVMe Gen4</li><li>Nguồn: 650W 80Plus Bronze</li></ul>", true),
            New("MHI-001", "Màn hình Dell P2422H 24 inch IPS FHD", "man-hinh-may-tinh", "Dell", 3990000, 4590000, 40, "monitor-1",
                "Màn hình 24\" IPS, viền mỏng, chân đế nâng hạ xoay dọc.",
                "<p>Dell P2422H là màn hình văn phòng tiêu chuẩn với khả năng bảo vệ mắt ComfortView Plus.</p><h3>Thông số kỹ thuật</h3><ul><li>Kích thước: 23.8 inch</li><li>Tấm nền: IPS, Full HD 1920x1080</li><li>Tần số quét: 60Hz, thời gian phản hồi 5ms</li><li>Cổng: HDMI, DisplayPort, VGA, 4x USB</li></ul>", false),
            New("MHI-002", "Màn hình Gaming LG UltraGear 27GP850 27 inch 2K 165Hz", "man-hinh-may-tinh", "LG", 9490000, 10990000, 15, "monitor-2",
                "Tấm nền Nano IPS 2K, 165Hz, 1ms, hỗ trợ G-Sync và FreeSync Premium.",
                "<p>LG UltraGear 27GP850 phù hợp cho cả chơi game tốc độ cao lẫn công việc đồ hoạ.</p><h3>Thông số kỹ thuật</h3><ul><li>Độ phân giải: 2560x1440 (QHD)</li><li>Tần số quét: 165Hz (ép xung 180Hz)</li><li>Độ phủ màu: 98% DCI-P3</li><li>HDR: VESA DisplayHDR 400</li></ul>", true),

            New("DTH-001", "Samsung Galaxy S24 5G 8GB 256GB", "dien-thoai-thong-minh", "Samsung", 21990000, 23990000, 22, "phone-1",
                "Chip Snapdragon 8 Gen 3, màn hình Dynamic AMOLED 2X 120Hz, Galaxy AI.",
                "<p>Galaxy S24 là thế hệ điện thoại đầu tiên của Samsung tích hợp sâu Galaxy AI.</p><h3>Thông số kỹ thuật</h3><ul><li>Màn hình: 6.2 inch Dynamic AMOLED 2X, 120Hz</li><li>Chip: Snapdragon 8 Gen 3 for Galaxy</li><li>Camera: 50MP + 12MP góc rộng + 10MP tele</li><li>Pin: 4000mAh, sạc nhanh 25W</li></ul>", true),
            New("DTH-002", "iPhone 15 128GB", "dien-thoai-thong-minh", "Apple", 19990000, 22990000, 17, "phone-2",
                "Chip A16 Bionic, camera chính 48MP, cổng USB-C, Dynamic Island.",
                "<p>iPhone 15 mang nhiều nâng cấp đáng giá so với thế hệ trước, đặc biệt là cổng USB-C.</p><h3>Thông số kỹ thuật</h3><ul><li>Màn hình: 6.1 inch Super Retina XDR</li><li>Chip: Apple A16 Bionic</li><li>Camera: 48MP chính + 12MP siêu rộng</li><li>Kết nối: USB-C, 5G, Wi-Fi 6</li></ul>", true),
            New("DTH-003", "Xiaomi Redmi Note 13 Pro 8GB 256GB", "dien-thoai-thong-minh", "Xiaomi", 6490000, 7490000, 35, "phone-3",
                "Camera 200MP, màn hình AMOLED 120Hz, sạc nhanh 67W.",
                "<p>Redmi Note 13 Pro tiếp tục là lựa chọn hàng đầu trong phân khúc phổ thông.</p><h3>Thông số kỹ thuật</h3><ul><li>Màn hình: 6.67 inch AMOLED 120Hz</li><li>Chip: MediaTek Helio G99 Ultra</li><li>Camera: 200MP OIS</li><li>Pin: 5000mAh, sạc 67W</li></ul>", false),
            New("MTB-001", "iPad Gen 10 WiFi 64GB", "may-tinh-bang", "Apple", 10990000, 12990000, 19, "tablet-1",
                "Màn hình 10.9 inch Liquid Retina, chip A14 Bionic, hỗ trợ Apple Pencil.",
                "<p>iPad Gen 10 là máy tính bảng phổ thông tốt nhất cho học tập và giải trí.</p><h3>Thông số kỹ thuật</h3><ul><li>Màn hình: 10.9 inch Liquid Retina</li><li>Chip: Apple A14 Bionic</li><li>Camera trước: 12MP đặt cạnh ngang</li><li>Kết nối: USB-C</li></ul>", false),

            New("BPC-001", "Bàn phím cơ Akko 3068B Plus World Tour Tokyo", "ban-phim-chuot", "Akko", 1690000, 1990000, 50, "keyboard-1",
                "Bàn phím cơ 65%, kết nối 3 chế độ Bluetooth / 2.4GHz / USB-C.",
                "<p>Akko 3068B Plus nổi bật với bộ keycap PBT Double-shot bền màu.</p><h3>Thông số kỹ thuật</h3><ul><li>Layout: 68 phím (65%)</li><li>Switch: Akko CS Jelly Purple, hot-swap</li><li>Kết nối: Bluetooth 5.0 / 2.4GHz / USB-C</li><li>Pin: 3000mAh</li></ul>", true),
            New("BPC-002", "Chuột không dây Logitech MX Master 3S", "ban-phim-chuot", "Logitech", 2390000, 2790000, 45, "mouse-1",
                "Cảm biến 8000 DPI, cuộn MagSpeed, click siêu êm, kết nối 3 thiết bị.",
                "<p>MX Master 3S là chuột năng suất cao được giới lập trình viên và nhà thiết kế ưa chuộng.</p><h3>Thông số kỹ thuật</h3><ul><li>Cảm biến: Darkfield 8000 DPI</li><li>Kết nối: Bluetooth / Logi Bolt, tối đa 3 thiết bị</li><li>Pin: sạc 1 phút dùng 3 giờ, đầy dùng 70 ngày</li></ul>", true),
            New("TNL-001", "Tai nghe Sony WH-1000XM5 Chống ồn", "tai-nghe-loa", "Sony", 6990000, 8490000, 23, "headphone-1",
                "Chống ồn chủ động hàng đầu thị trường, pin 30 giờ, sạc nhanh 3 phút dùng 3 giờ.",
                "<p>Sony WH-1000XM5 sử dụng 8 micro và 2 vi xử lý để loại bỏ tiếng ồn môi trường.</p><h3>Thông số kỹ thuật</h3><ul><li>Driver: 30mm carbon fiber</li><li>Chống ồn: QN1 + V1 dual processor</li><li>Pin: 30 giờ (bật ANC)</li><li>Codec: LDAC, AAC, SBC</li></ul>", true),
            New("TNL-002", "Loa Bluetooth JBL Charge 5", "tai-nghe-loa", "JBL", 3290000, 3990000, 30, "speaker-1",
                "Chuẩn chống nước IP67, pin 20 giờ, kiêm sạc dự phòng cho điện thoại.",
                "<p>JBL Charge 5 cho âm bass mạnh mẽ và độ bền cao, phù hợp mang đi dã ngoại.</p><h3>Thông số kỹ thuật</h3><ul><li>Công suất: 40W RMS</li><li>Pin: 7500mAh, 20 giờ phát nhạc</li><li>Kháng nước: IP67</li></ul>", false),
            New("OCU-001", "Ổ cứng SSD Samsung 980 PRO 1TB NVMe PCIe 4.0", "o-cung-bo-nho", "Samsung", 2790000, 3290000, 60, "ssd-1",
                "Tốc độ đọc 7000MB/s, ghi 5000MB/s - lý tưởng cho dựng phim và chơi game.",
                "<p>Samsung 980 PRO là một trong những SSD PCIe 4.0 nhanh nhất hiện nay.</p><h3>Thông số kỹ thuật</h3><ul><li>Chuẩn: M.2 2280 NVMe PCIe 4.0 x4</li><li>Tốc độ đọc/ghi: 7000 / 5000 MB/s</li><li>Độ bền: 600 TBW</li><li>Bảo hành: 5 năm</li></ul>", true),
            New("OCU-002", "RAM Kingston Fury Beast 16GB DDR4 3200MHz", "o-cung-bo-nho", "Kingston", 1090000, 1290000, 70, "ram-1",
                "Tản nhiệt nhôm, hỗ trợ XMP 2.0, bảo hành trọn đời.",
                "<p>Kingston Fury Beast là lựa chọn nâng cấp RAM phổ biến nhờ độ tương thích cao.</p><h3>Thông số kỹ thuật</h3><ul><li>Dung lượng: 16GB (1x16GB)</li><li>Bus: 3200MHz, CL16</li><li>Điện áp: 1.35V</li><li>Bảo hành: trọn đời</li></ul>", false),

            New("RTS-001", "Router WiFi 6 TP-Link Archer AX55", "router-switch", "TP-Link", 1890000, 2290000, 38, "router-1",
                "WiFi 6 chuẩn AX3000, 4 ăng-ten, hỗ trợ OFDMA và MU-MIMO.",
                "<p>Archer AX55 phù hợp cho hộ gia đình và văn phòng nhỏ dưới 30 thiết bị.</p><h3>Thông số kỹ thuật</h3><ul><li>Chuẩn: WiFi 6 AX3000 (2402 + 574 Mbps)</li><li>Cổng: 1 WAN + 4 LAN Gigabit</li><li>Bảo mật: WPA3, HomeShield</li></ul>", false),
            New("RTS-002", "Switch Cisco SG250-26 24 cổng Gigabit", "router-switch", "Cisco", 6490000, null, 10, "switch-1",
                "Switch quản lý lớp 2, 24 cổng Gigabit + 2 cổng SFP, hỗ trợ VLAN.",
                "<p>Cisco SG250-26 là switch quản lý thông minh cho hệ thống mạng doanh nghiệp vừa.</p><h3>Thông số kỹ thuật</h3><ul><li>Cổng: 24 x 10/100/1000 + 2 x SFP</li><li>Quản lý: Web GUI, VLAN, QoS, ACL</li><li>Công suất chuyển mạch: 52 Gbps</li></ul>", false),
            New("MIN-001", "Máy in laser Canon LBP2900 (in đen trắng)", "may-in-may-quet", "Canon", 3490000, 3890000, 25, "printer-1",
                "Tốc độ in 12 trang/phút, độ bền cao, chi phí vận hành thấp.",
                "<p>Canon LBP2900 là máy in laser đen trắng bán chạy nhất tại Việt Nam nhiều năm liền.</p><h3>Thông số kỹ thuật</h3><ul><li>Tốc độ: 12 trang/phút A4</li><li>Độ phân giải: 600 x 600 dpi</li><li>Kết nối: USB 2.0</li><li>Hộp mực: Canon 303</li></ul>", false),
            New("CAM-001", "Camera IP Wifi Imou Ranger 2 4MP", "camera-giam-sat", "Imou", 990000, 1290000, 55, "camera-1",
                "Xoay 360 độ, đàm thoại 2 chiều, phát hiện chuyển động và theo dõi tự động.",
                "<p>Imou Ranger 2 cho phép giám sát từ xa qua điện thoại với chất lượng 4MP sắc nét.</p><h3>Thông số kỹ thuật</h3><ul><li>Độ phân giải: 4MP (2560x1440)</li><li>Góc xoay: ngang 355°, dọc 90°</li><li>Hồng ngoại: 10m</li><li>Lưu trữ: thẻ nhớ tới 256GB hoặc đám mây</li></ul>", true),

            NewService("DV-001", "Gói bảo trì hệ thống CNTT doanh nghiệp (12 tháng)", "bao-tri-he-thong", 12000000, 999, "service-1",
                "Bảo trì định kỳ hàng tháng cho hệ thống máy tính, mạng và máy chủ của doanh nghiệp.",
                "<p>Gói dịch vụ dành cho doanh nghiệp có từ 20 đến 100 máy trạm.</p><h3>Nội dung dịch vụ</h3><ul><li>Kiểm tra và bảo dưỡng thiết bị định kỳ 1 lần/tháng</li><li>Hỗ trợ kỹ thuật từ xa không giới hạn trong giờ hành chính</li><li>Cử kỹ thuật viên tới nơi trong 4 giờ khi có sự cố nghiêm trọng</li><li>Sao lưu và kiểm tra khả năng phục hồi dữ liệu hàng quý</li></ul>"),
            NewService("DV-002", "Thiết kế website giới thiệu doanh nghiệp trọn gói", "thiet-ke-website", 15000000, 999, "service-2",
                "Website chuẩn responsive, tối ưu SEO, bàn giao đầy đủ mã nguồn trong 30 ngày.",
                "<p>TOANTECH thiết kế website theo nhận diện thương hiệu riêng của từng khách hàng.</p><h3>Gói dịch vụ bao gồm</h3><ul><li>Tư vấn và thiết kế giao diện riêng (không dùng theme có sẵn)</li><li>Lập trình trên nền ASP.NET Core, quản trị nội dung dễ dùng</li><li>Tặng 1 năm tên miền .com và hosting</li><li>Bàn giao mã nguồn và hướng dẫn sử dụng</li><li>Bảo hành 12 tháng</li></ul>")
        };

        context.Products.AddRange(products);
        await context.SaveChangesAsync();

        Product New(string sku, string name, string categorySlug, string brand,
                    decimal price, decimal? oldPrice, int stock, string image,
                    string shortDesc, string description, bool featured) => new()
        {
            Sku = sku,
            Name = name,
            Slug = Services.SlugHelper.Generate(name),
            CategoryId = Cat(categorySlug),
            Brand = brand,
            Price = price,
            OldPrice = oldPrice,
            StockQuantity = stock,
            ImageUrl = $"/images/products/{image}.svg",
            ShortDescription = shortDesc,
            Description = description,
            IsFeatured = featured,
            IsActive = true,
            ViewCount = Random.Shared.Next(50, 900),
            CreatedAt = DateTime.Now.AddDays(-Random.Shared.Next(1, 120))
        };

        Product NewService(string sku, string name, string categorySlug, decimal price,
                           int stock, string image, string shortDesc, string description) => new()
        {
            Sku = sku,
            Name = name,
            Slug = Services.SlugHelper.Generate(name),
            CategoryId = Cat(categorySlug),
            Brand = "TOANTECH",
            Price = price,
            StockQuantity = stock,
            ImageUrl = $"/images/products/{image}.svg",
            ShortDescription = shortDesc,
            Description = description,
            IsFeatured = false,
            IsActive = true,
            ViewCount = Random.Shared.Next(30, 300),
            CreatedAt = DateTime.Now.AddDays(-Random.Shared.Next(1, 60))
        };
    }

    // ------------------------------------------------------------------- News
    private static async Task SeedNewsAsync(ApplicationDbContext context)
    {
        if (await context.NewsCategories.AnyAsync()) return;

        var company = new NewsCategory { Name = "Tin công ty", Slug = "tin-cong-ty", DisplayOrder = 1 };
        var promo = new NewsCategory { Name = "Khuyến mại", Slug = "khuyen-mai", DisplayOrder = 2 };
        var tech = new NewsCategory { Name = "Công nghệ", Slug = "cong-nghe", DisplayOrder = 3 };
        var guide = new NewsCategory { Name = "Hướng dẫn - Thủ thuật", Slug = "huong-dan-thu-thuat", DisplayOrder = 4 };

        context.NewsCategories.AddRange(company, promo, tech, guide);
        await context.SaveChangesAsync();

        var articles = new List<NewsArticle>
        {
            Article("TOANTECH khai trương chi nhánh thứ 5 tại Thành phố Hải Phòng", company.Id, "news-1",
                "Sáng 12/8/2026, Công ty Cổ phần Công nghệ TOANTECH chính thức khai trương chi nhánh thứ 5 tại số 216 Lạch Tray, quận Ngô Quyền, TP. Hải Phòng.",
                "<p>Sáng ngày 12/8/2026, Công ty Cổ phần Công nghệ TOANTECH chính thức khai trương chi nhánh thứ 5 tại số 216 Lạch Tray, quận Ngô Quyền, thành phố Hải Phòng.</p>" +
                "<p>Chi nhánh mới có diện tích 450m², bao gồm khu trưng bày sản phẩm, khu trải nghiệm thiết bị và trung tâm bảo hành uỷ quyền. Đây là bước đi nằm trong chiến lược mở rộng mạng lưới phân phối ra các tỉnh thành phía Bắc của công ty giai đoạn 2026 - 2028.</p>" +
                "<h3>Ưu đãi mừng khai trương</h3><ul><li>Giảm tới 15% toàn bộ laptop và máy tính để bàn</li><li>Tặng gói bảo hành mở rộng 6 tháng cho 100 khách hàng đầu tiên</li><li>Miễn phí vệ sinh, bảo dưỡng máy tính trong tháng 8</li></ul>" +
                "<p>Ông Lưu Đức Toàn - Tổng Giám đốc TOANTECH - chia sẻ: \"Hải Phòng là thị trường trọng điểm với tốc độ chuyển đổi số rất nhanh. Chúng tôi muốn ở gần khách hàng hơn để rút ngắn thời gian phục vụ.\"</p>", true),

            Article("Chương trình \"Back to School 2026\": giảm đến 25% cho học sinh, sinh viên", promo.Id, "news-2",
                "Từ ngày 01/9 đến 30/9/2026, TOANTECH triển khai chương trình ưu đãi lớn nhất năm dành riêng cho học sinh, sinh viên.",
                "<p>Từ ngày 01/9 đến hết 30/9/2026, TOANTECH triển khai chương trình <strong>Back to School 2026</strong> với nhiều ưu đãi hấp dẫn.</p>" +
                "<h3>Nội dung chương trình</h3><ul><li>Giảm đến 25% cho toàn bộ laptop văn phòng khi xuất trình thẻ học sinh/sinh viên</li><li>Tặng balo chống sốc và chuột không dây trị giá 890.000đ</li><li>Trả góp 0% lãi suất trong 12 tháng qua thẻ tín dụng</li><li>Thu cũ đổi mới, trợ giá tới 2.000.000đ</li></ul>" +
                "<h3>Điều kiện áp dụng</h3><p>Chương trình áp dụng tại tất cả chi nhánh và trên website chính thức. Mỗi khách hàng được hưởng ưu đãi tối đa 01 lần. Không áp dụng đồng thời với các chương trình khuyến mại khác.</p>", true),

            Article("Vì sao doanh nghiệp nên chuyển từ ổ cứng HDD sang SSD NVMe?", tech.Id, "news-3",
                "Chi phí nâng cấp SSD đã giảm mạnh, trong khi hiệu quả làm việc tăng rõ rệt. Bài viết phân tích bài toán đầu tư dưới góc nhìn doanh nghiệp.",
                "<p>Nhiều doanh nghiệp vẫn đang dùng máy tính với ổ cứng HDD từ 5 - 7 năm trước. Việc nâng cấp lên SSD NVMe hiện có chi phí thấp hơn nhiều so với thay máy mới.</p>" +
                "<h3>So sánh nhanh</h3><table><thead><tr><th>Tiêu chí</th><th>HDD 7200rpm</th><th>SSD NVMe PCIe 4.0</th></tr></thead>" +
                "<tbody><tr><td>Tốc độ đọc tuần tự</td><td>~120 MB/s</td><td>~7000 MB/s</td></tr>" +
                "<tr><td>Thời gian khởi động Windows</td><td>60 - 90 giây</td><td>8 - 12 giây</td></tr>" +
                "<tr><td>Độ ồn</td><td>Có tiếng quay đĩa</td><td>Hoàn toàn yên tĩnh</td></tr>" +
                "<tr><td>Chống sốc</td><td>Kém</td><td>Tốt (không có bộ phận chuyển động)</td></tr></tbody></table>" +
                "<h3>Bài toán chi phí</h3><p>Với chi phí khoảng 1.500.000đ cho mỗi máy, doanh nghiệp có thể kéo dài tuổi thọ thiết bị thêm 2 - 3 năm. Nếu mỗi nhân viên tiết kiệm 10 phút chờ máy mỗi ngày, khoản đầu tư này hoàn vốn chỉ sau vài tháng.</p>", false),

            Article("Hướng dẫn 7 bước bảo vệ máy tính doanh nghiệp khỏi mã độc tống tiền", guide.Id, "news-4",
                "Ransomware tiếp tục là mối đe doạ hàng đầu với doanh nghiệp vừa và nhỏ. Đội ngũ kỹ thuật TOANTECH tổng hợp 7 biện pháp cơ bản nhưng hiệu quả.",
                "<p>Theo thống kê của các hãng bảo mật, số vụ tấn công bằng mã độc tống tiền nhắm vào doanh nghiệp vừa và nhỏ tại Việt Nam tăng đều qua từng năm. Dưới đây là 7 biện pháp cơ bản mà bất kỳ doanh nghiệp nào cũng nên áp dụng.</p>" +
                "<ol><li><strong>Sao lưu theo quy tắc 3-2-1:</strong> giữ 3 bản sao dữ liệu, trên 2 loại phương tiện khác nhau, trong đó 1 bản đặt ngoài văn phòng.</li>" +
                "<li><strong>Cập nhật hệ điều hành và phần mềm:</strong> phần lớn mã độc khai thác lỗ hổng đã có bản vá.</li>" +
                "<li><strong>Không dùng tài khoản quản trị cho công việc hàng ngày:</strong> áp dụng nguyên tắc đặc quyền tối thiểu.</li>" +
                "<li><strong>Bật xác thực hai yếu tố</strong> cho email và các dịch vụ đám mây.</li>" +
                "<li><strong>Đào tạo nhân viên nhận biết email lừa đảo:</strong> con người vẫn là mắt xích yếu nhất.</li>" +
                "<li><strong>Phân đoạn mạng (VLAN):</strong> hạn chế mã độc lây lan giữa các phòng ban.</li>" +
                "<li><strong>Lập sẵn kịch bản ứng phó sự cố</strong> và diễn tập ít nhất 1 lần mỗi năm.</li></ol>" +
                "<p>TOANTECH cung cấp dịch vụ đánh giá an toàn thông tin miễn phí cho doanh nghiệp dưới 50 máy trạm. Quý khách vui lòng liên hệ hotline để đặt lịch.</p>", true),

            Article("TOANTECH đạt chứng nhận Nhà phân phối uỷ quyền của Dell Technologies", company.Id, "news-5",
                "Ngày 05/7/2026, Dell Technologies Việt Nam trao chứng nhận Authorized Distributor cho TOANTECH.",
                "<p>Ngày 05/7/2026, tại Hà Nội, Dell Technologies Việt Nam đã trao chứng nhận <em>Authorized Distributor</em> cho Công ty Cổ phần Công nghệ TOANTECH.</p>" +
                "<p>Chứng nhận này ghi nhận năng lực phân phối và chất lượng dịch vụ hậu mãi của công ty trong suốt 3 năm hợp tác. Với vị thế mới, TOANTECH được tiếp cận trực tiếp nguồn hàng từ nhà máy, qua đó rút ngắn thời gian giao hàng và tối ưu giá bán cho khách hàng.</p>" +
                "<p>Trong quý IV/2026, công ty dự kiến mở rộng danh mục sang dòng máy chủ Dell PowerEdge và thiết bị lưu trữ Dell PowerVault.</p>", false),

            Article("5 tiêu chí chọn laptop phù hợp cho nhân viên văn phòng", guide.Id, "news-6",
                "Không phải cứ cấu hình cao là tốt. Bài viết giúp bộ phận hành chính - nhân sự chọn đúng thiết bị với ngân sách hợp lý.",
                "<p>Khi mua sắm laptop số lượng lớn cho doanh nghiệp, việc chọn đúng cấu hình giúp tiết kiệm đáng kể ngân sách mà vẫn đảm bảo hiệu quả công việc.</p>" +
                "<h3>1. Xác định đúng nhu cầu sử dụng</h3><p>Nhân viên kế toán, hành chính chỉ cần Core i3/i5 với 8 - 16GB RAM. Ngược lại, bộ phận thiết kế hoặc kỹ thuật cần card đồ hoạ rời và màn hình chuẩn màu.</p>" +
                "<h3>2. Ưu tiên RAM và SSD hơn là CPU</h3><p>Nâng RAM từ 8GB lên 16GB thường mang lại cảm nhận rõ rệt hơn việc nâng CPU lên một bậc.</p>" +
                "<h3>3. Chú ý khối lượng và thời lượng pin</h3><p>Với nhân viên hay đi công tác, máy dưới 1.5kg và pin trên 8 giờ là tiêu chí quan trọng hàng đầu.</p>" +
                "<h3>4. Kiểm tra chính sách bảo hành</h3><p>Gói bảo hành tại chỗ (onsite) giúp doanh nghiệp không bị gián đoạn công việc khi máy hỏng.</p>" +
                "<h3>5. Tính tổng chi phí sở hữu</h3><p>Nên tính cả chi phí bảo trì, thay pin và nâng cấp trong vòng đời 4 - 5 năm, thay vì chỉ nhìn vào giá mua ban đầu.</p>", false)
        };

        context.NewsArticles.AddRange(articles);
        await context.SaveChangesAsync();

        NewsArticle Article(string title, int categoryId, string image, string summary, string content, bool featured) => new()
        {
            Title = title,
            Slug = Services.SlugHelper.Generate(title),
            NewsCategoryId = categoryId,
            Summary = summary,
            Content = content,
            ImageUrl = $"/images/news/{image}.svg",
            Author = "Ban Truyền thông TOANTECH",
            IsPublished = true,
            IsFeatured = featured,
            ViewCount = Random.Shared.Next(100, 2000),
            PublishedAt = DateTime.Now.AddDays(-Random.Shared.Next(1, 60))
        };
    }

    // ----------------------------------------------------------- Sample orders
    private static async Task SeedSampleOrdersAsync(
        ApplicationDbContext context,
        UserManager<ApplicationUser> userManager,
        IConfiguration configuration)
    {
        if (await context.Orders.AnyAsync()) return;

        var customer = await userManager.FindByEmailAsync(configuration["SeedAccounts:CustomerEmail"]!);
        var products = await context.Products
            .Where(p => p.Price < 30000000)
            .OrderBy(p => p.Id)
            .Take(10)
            .ToListAsync();
        if (products.Count == 0) return;

        var statuses = new[] { OrderStatus.Completed, OrderStatus.Completed, OrderStatus.Shipping, OrderStatus.Confirmed, OrderStatus.Pending, OrderStatus.Cancelled };
        var names = new[] { "Nguyễn Văn Khách", "Phạm Thu Hà", "Đỗ Minh Quân", "Lê Thị Mai", "Hoàng Anh Tuấn" };
        var addresses = new[]
        {
            "Số 5 Lê Duẩn, Hoàn Kiếm, Hà Nội",
            "12 Nguyễn Trãi, Thanh Xuân, Hà Nội",
            "88 Trần Phú, Hà Đông, Hà Nội",
            "216 Lạch Tray, Ngô Quyền, Hải Phòng",
            "45 Lê Hồng Phong, TP. Nam Định"
        };

        var orders = new List<Order>();
        for (var i = 0; i < 18; i++)
        {
            var createdAt = DateTime.Now.AddDays(-Random.Shared.Next(0, 170));
            var status = statuses[Random.Shared.Next(statuses.Length)];
            var nameIndex = Random.Shared.Next(names.Length);

            var order = new Order
            {
                OrderCode = $"TT{createdAt:yyMMdd}{(1000 + i)}",
                UserId = nameIndex == 0 ? customer?.Id : null,
                CustomerName = names[nameIndex],
                CustomerPhone = $"09{Random.Shared.Next(10000000, 99999999)}",
                CustomerEmail = nameIndex == 0 ? configuration["SeedAccounts:CustomerEmail"]! : $"khach{i}@example.com",
                ShippingAddress = addresses[nameIndex],
                PaymentMethod = Random.Shared.Next(2) == 0 ? PaymentMethod.CashOnDelivery : PaymentMethod.BankTransfer,
                Status = status,
                CreatedAt = createdAt,
                UpdatedAt = status == OrderStatus.Pending ? null : createdAt.AddDays(1),
                CancelReason = status == OrderStatus.Cancelled ? "Khách hàng đổi ý, không có nhu cầu nữa." : null
            };

            var lineCount = Random.Shared.Next(1, 4);
            var chosen = products.OrderBy(_ => Random.Shared.Next()).Take(lineCount).ToList();
            foreach (var product in chosen)
            {
                var qty = Random.Shared.Next(1, 3);
                order.OrderDetails.Add(new OrderDetail
                {
                    ProductId = product.Id,
                    ProductName = product.Name,
                    UnitPrice = product.Price,
                    Quantity = qty,
                    LineTotal = product.Price * qty
                });
            }

            order.SubTotal = order.OrderDetails.Sum(d => d.LineTotal);
            var freeThreshold = configuration.GetValue<decimal>("SiteSettings:FreeShipThreshold");
            order.ShippingFee = order.SubTotal >= freeThreshold ? 0 : configuration.GetValue<decimal>("SiteSettings:ShippingFee");
            order.TotalAmount = order.SubTotal + order.ShippingFee;

            orders.Add(order);
        }

        context.Orders.AddRange(orders);

        context.ContactMessages.AddRange(
            new ContactMessage
            {
                FullName = "Trần Quốc Bảo",
                Email = "baotq@congtyabc.vn",
                Phone = "0913456789",
                Subject = "Báo giá 30 bộ máy tính văn phòng",
                Message = "Công ty chúng tôi cần trang bị 30 bộ máy tính để bàn cho văn phòng mới. Mong TOANTECH gửi báo giá và cấu hình đề xuất trong tuần này. Xin cảm ơn.",
                CreatedAt = DateTime.Now.AddDays(-2)
            },
            new ContactMessage
            {
                FullName = "Nguyễn Thị Lan",
                Email = "lan.nguyen@gmail.com",
                Phone = "0977123456",
                Subject = "Hỏi về chính sách bảo hành laptop",
                Message = "Tôi mua laptop Dell tại cửa hàng tháng trước, máy bị lỗi bàn phím. Cho tôi hỏi thủ tục bảo hành cần mang theo giấy tờ gì ạ?",
                IsHandled = true,
                CreatedAt = DateTime.Now.AddDays(-9)
            });

        await context.SaveChangesAsync();
    }
}
