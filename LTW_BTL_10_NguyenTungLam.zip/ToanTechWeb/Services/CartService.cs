using System.Text.Json;
using ToanTechWeb.Models.ViewModels;

namespace ToanTechWeb.Services;

public interface ICartService
{
    List<CartItem> GetItems();
    void AddItem(CartItem item);
    void UpdateQuantity(int productId, int quantity);
    void RemoveItem(int productId);
    void Clear();
    int GetTotalQuantity();
    CartViewModel GetCart();
}

/// <summary>
/// Giỏ hàng lưu trong Session của máy chủ (serialise sang JSON).
/// Chọn Session thay vì Cookie để phía người dùng KHÔNG thể sửa giá sản phẩm.
/// Giá thực tế vẫn được đọc lại từ CSDL một lần nữa khi đặt hàng.
/// </summary>
public class CartService : ICartService
{
    private const string SessionKey = "TOANTECH_CART";
    private readonly IHttpContextAccessor _accessor;
    private readonly IConfiguration _configuration;

    public CartService(IHttpContextAccessor accessor, IConfiguration configuration)
    {
        _accessor = accessor;
        _configuration = configuration;
    }

    private ISession Session =>
        _accessor.HttpContext?.Session
        ?? throw new InvalidOperationException("Session chưa được cấu hình trong pipeline.");

    public List<CartItem> GetItems()
    {
        var json = Session.GetString(SessionKey);
        if (string.IsNullOrEmpty(json)) return new List<CartItem>();

        try
        {
            return JsonSerializer.Deserialize<List<CartItem>>(json) ?? new List<CartItem>();
        }
        catch (JsonException)
        {
            // Dữ liệu session hỏng -> bỏ qua, trả giỏ rỗng thay vì làm sập trang.
            return new List<CartItem>();
        }
    }

    private void Save(List<CartItem> items) =>
        Session.SetString(SessionKey, JsonSerializer.Serialize(items));

    public void AddItem(CartItem item)
    {
        var items = GetItems();
        var existing = items.FirstOrDefault(i => i.ProductId == item.ProductId);

        if (existing is null)
        {
            items.Add(item);
        }
        else
        {
            existing.Quantity += item.Quantity;
            existing.UnitPrice = item.UnitPrice; // cập nhật theo giá mới nhất
        }

        // Chặn số lượng vô lý dù người dùng có sửa request.
        foreach (var i in items)
            i.Quantity = Math.Clamp(i.Quantity, 1, 1000);

        Save(items);
    }

    public void UpdateQuantity(int productId, int quantity)
    {
        var items = GetItems();
        var existing = items.FirstOrDefault(i => i.ProductId == productId);
        if (existing is null) return;

        if (quantity <= 0)
            items.Remove(existing);
        else
            existing.Quantity = Math.Min(quantity, 1000);

        Save(items);
    }

    public void RemoveItem(int productId)
    {
        var items = GetItems();
        items.RemoveAll(i => i.ProductId == productId);
        Save(items);
    }

    public void Clear() => Session.Remove(SessionKey);

    public int GetTotalQuantity() => GetItems().Sum(i => i.Quantity);

    public CartViewModel GetCart()
    {
        var items = GetItems();
        var subTotal = items.Sum(i => i.LineTotal);

        var fee = _configuration.GetValue<decimal>("SiteSettings:ShippingFee");
        var freeThreshold = _configuration.GetValue<decimal>("SiteSettings:FreeShipThreshold");

        return new CartViewModel
        {
            Items = items,
            // Miễn phí vận chuyển khi giỏ rỗng hoặc đạt ngưỡng khuyến mại.
            ShippingFee = (items.Count == 0 || subTotal >= freeThreshold) ? 0 : fee
        };
    }
}
