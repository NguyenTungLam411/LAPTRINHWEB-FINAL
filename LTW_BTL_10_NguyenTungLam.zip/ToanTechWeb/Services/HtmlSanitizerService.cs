using Ganss.Xss;

namespace ToanTechWeb.Services;

public interface IHtmlSanitizerService
{
    string Sanitize(string? html);
}

/// <summary>
/// Làm sạch nội dung HTML do quản trị viên nhập (mô tả sản phẩm, bài viết)
/// trước khi lưu xuống CSDL - chống XSS lưu trữ (Stored XSS).
/// Cơ chế: danh sách TRẮNG thẻ và thuộc tính; mọi thứ ngoài danh sách bị loại bỏ.
/// </summary>
public class HtmlSanitizerService : IHtmlSanitizerService
{
    private readonly HtmlSanitizer _sanitizer;

    public HtmlSanitizerService()
    {
        _sanitizer = new HtmlSanitizer();

        _sanitizer.AllowedTags.Clear();
        foreach (var tag in new[]
                 {
                     "p", "br", "strong", "b", "em", "i", "u", "s", "ul", "ol", "li",
                     "h2", "h3", "h4", "h5", "blockquote", "a", "img", "table",
                     "thead", "tbody", "tr", "th", "td", "span", "div", "hr", "figure", "figcaption"
                 })
        {
            _sanitizer.AllowedTags.Add(tag);
        }

        _sanitizer.AllowedAttributes.Clear();
        foreach (var attr in new[] { "href", "title", "src", "alt", "width", "height", "class", "target", "rel" })
        {
            _sanitizer.AllowedAttributes.Add(attr);
        }

        // Chỉ cho phép các giao thức an toàn -> chặn href="javascript:..."
        _sanitizer.AllowedSchemes.Clear();
        _sanitizer.AllowedSchemes.Add("http");
        _sanitizer.AllowedSchemes.Add("https");
        _sanitizer.AllowedSchemes.Add("mailto");

        // Chặn hoàn toàn CSS nội tuyến (có thể dùng để che phủ giao diện - clickjacking).
        _sanitizer.AllowedCssProperties.Clear();

        // Mọi liên kết ra ngoài đều gắn rel chống tấn công tabnabbing.
        _sanitizer.PostProcessNode += (_, e) =>
        {
            if (e.Node is AngleSharp.Html.Dom.IHtmlAnchorElement anchor && anchor.HasAttribute("target"))
            {
                anchor.SetAttribute("rel", "noopener noreferrer");
            }
        };
    }

    public string Sanitize(string? html) =>
        string.IsNullOrWhiteSpace(html) ? string.Empty : _sanitizer.Sanitize(html);
}
