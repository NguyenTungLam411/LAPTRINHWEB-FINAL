namespace ToanTechWeb.Services;

public interface IFileUploadService
{
    Task<(bool Success, string? Path, string? Error)> SaveImageAsync(IFormFile? file, string subFolder);
    void Delete(string? relativePath);
}

/// <summary>
/// Xử lý tải ảnh lên. Kiểm tra nhiều lớp để chống tấn công tải tệp độc hại:
///  1. Danh sách trắng phần mở rộng.
///  2. Danh sách trắng MIME type.
///  3. Giới hạn dung lượng.
///  4. Kiểm tra "magic number" (chữ ký nhị phân) - chống đổi đuôi .aspx thành .jpg.
///  5. Sinh tên tệp ngẫu nhiên (GUID) - chống ghi đè và chống path traversal.
/// </summary>
public class FileUploadService : IFileUploadService
{
    private const long MaxFileSize = 4 * 1024 * 1024; // 4 MB

    private static readonly string[] AllowedExtensions = { ".jpg", ".jpeg", ".png", ".gif", ".webp" };

    private static readonly string[] AllowedContentTypes =
        { "image/jpeg", "image/pjpeg", "image/png", "image/gif", "image/webp" };

    /// <summary>Chữ ký nhị phân đầu tệp của từng định dạng ảnh hợp lệ.</summary>
    private static readonly Dictionary<string, List<byte[]>> FileSignatures = new()
    {
        [".jpg"] = new List<byte[]> { new byte[] { 0xFF, 0xD8, 0xFF } },
        [".jpeg"] = new List<byte[]> { new byte[] { 0xFF, 0xD8, 0xFF } },
        [".png"] = new List<byte[]> { new byte[] { 0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A } },
        [".gif"] = new List<byte[]> { "GIF87a"u8.ToArray(), "GIF89a"u8.ToArray() },
        [".webp"] = new List<byte[]> { "RIFF"u8.ToArray() }
    };

    private readonly IWebHostEnvironment _env;
    private readonly ILogger<FileUploadService> _logger;

    public FileUploadService(IWebHostEnvironment env, ILogger<FileUploadService> logger)
    {
        _env = env;
        _logger = logger;
    }

    public async Task<(bool Success, string? Path, string? Error)> SaveImageAsync(IFormFile? file, string subFolder)
    {
        if (file is null || file.Length == 0)
            return (true, null, null); // không chọn ảnh -> không phải lỗi

        if (file.Length > MaxFileSize)
            return (false, null, $"Ảnh vượt quá dung lượng cho phép ({MaxFileSize / 1024 / 1024} MB).");

        var extension = Path.GetExtension(file.FileName).ToLowerInvariant();

        if (!AllowedExtensions.Contains(extension))
            return (false, null, "Chỉ chấp nhận ảnh định dạng JPG, JPEG, PNG, GIF hoặc WEBP.");

        if (!AllowedContentTypes.Contains(file.ContentType.ToLowerInvariant()))
            return (false, null, "Kiểu nội dung của tệp không hợp lệ.");

        if (!await HasValidSignatureAsync(file, extension))
            return (false, null, "Nội dung tệp không phải là ảnh hợp lệ.");

        // Tên tệp do máy chủ sinh, KHÔNG dùng lại tên người dùng gửi lên.
        var safeFolder = Path.GetFileName(subFolder);
        var fileName = $"{Guid.NewGuid():N}{extension}";
        var uploadRoot = Path.Combine(_env.WebRootPath, "uploads", safeFolder);
        Directory.CreateDirectory(uploadRoot);

        var fullPath = Path.Combine(uploadRoot, fileName);
        await using (var stream = new FileStream(fullPath, FileMode.Create))
        {
            await file.CopyToAsync(stream);
        }

        _logger.LogInformation("Đã lưu ảnh {FileName} vào {Folder}", fileName, safeFolder);
        return (true, $"/uploads/{safeFolder}/{fileName}", null);
    }

    private static async Task<bool> HasValidSignatureAsync(IFormFile file, string extension)
    {
        if (!FileSignatures.TryGetValue(extension, out var signatures)) return false;

        await using var stream = file.OpenReadStream();
        var maxLength = signatures.Max(s => s.Length);
        var header = new byte[maxLength];
        var read = await stream.ReadAsync(header.AsMemory(0, maxLength));
        if (read < maxLength) return false;

        return signatures.Any(sig => header.Take(sig.Length).SequenceEqual(sig));
    }

    public void Delete(string? relativePath)
    {
        if (string.IsNullOrWhiteSpace(relativePath)) return;
        if (!relativePath.StartsWith("/uploads/", StringComparison.OrdinalIgnoreCase)) return;

        try
        {
            var fullPath = Path.Combine(_env.WebRootPath, relativePath.TrimStart('/').Replace('/', Path.DirectorySeparatorChar));

            // Chốt chặn cuối: đường dẫn sau khi chuẩn hoá phải nằm trong wwwroot/uploads.
            var uploadsRoot = Path.GetFullPath(Path.Combine(_env.WebRootPath, "uploads"));
            if (!Path.GetFullPath(fullPath).StartsWith(uploadsRoot, StringComparison.OrdinalIgnoreCase)) return;

            if (File.Exists(fullPath)) File.Delete(fullPath);
        }
        catch (IOException ex)
        {
            _logger.LogWarning(ex, "Không xoá được tệp {Path}", relativePath);
        }
    }
}
