using System.Globalization;
using System.Text;
using System.Text.RegularExpressions;

namespace ToanTechWeb.Services;

/// <summary>
/// Sinh slug thân thiện SEO từ tiếng Việt có dấu.
/// VD: "Laptop Dell Inspiron 15" -> "laptop-dell-inspiron-15".
/// </summary>
public static partial class SlugHelper
{
    [GeneratedRegex(@"[^a-z0-9\s-]")]
    private static partial Regex InvalidCharsRegex();

    [GeneratedRegex(@"[\s-]+")]
    private static partial Regex MultipleDashRegex();

    public static string Generate(string input)
    {
        if (string.IsNullOrWhiteSpace(input)) return string.Empty;

        // đ/Đ không nằm trong dải dấu Unicode nên phải thay tay trước.
        var text = input.Trim().ToLowerInvariant()
                        .Replace("đ", "d")
                        .Replace("Đ", "d");

        // Tách dấu khỏi ký tự gốc rồi loại bỏ các dấu (NonSpacingMark).
        var normalized = text.Normalize(NormalizationForm.FormD);
        var sb = new StringBuilder(normalized.Length);
        foreach (var c in normalized)
        {
            if (CharUnicodeInfo.GetUnicodeCategory(c) != UnicodeCategory.NonSpacingMark)
                sb.Append(c);
        }

        var result = sb.ToString().Normalize(NormalizationForm.FormC);
        result = InvalidCharsRegex().Replace(result, " ");
        result = MultipleDashRegex().Replace(result, "-").Trim('-');

        return result;
    }

    /// <summary>Sinh slug và thêm hậu tố -2, -3... nếu slug đã tồn tại.</summary>
    public static string GenerateUnique(string input, Func<string, bool> exists)
    {
        var baseSlug = Generate(input);
        if (string.IsNullOrEmpty(baseSlug)) baseSlug = "muc-" + DateTime.Now.Ticks;

        var slug = baseSlug;
        var counter = 2;
        while (exists(slug))
        {
            slug = $"{baseSlug}-{counter}";
            counter++;
        }
        return slug;
    }
}
