using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using ToanTechWeb.Data;
using ToanTechWeb.Models.Entities;
using ToanTechWeb.Models.ViewModels;
using ToanTechWeb.Services;

namespace ToanTechWeb.Areas.Admin.Controllers;

public class NewsController : AdminBaseController
{
    private const int PageSize = 15;

    private readonly ApplicationDbContext _context;
    private readonly IFileUploadService _upload;
    private readonly IHtmlSanitizerService _sanitizer;

    public NewsController(ApplicationDbContext context, IFileUploadService upload, IHtmlSanitizerService sanitizer)
    {
        _context = context;
        _upload = upload;
        _sanitizer = sanitizer;
    }

    public async Task<IActionResult> Index(string? keyword, int? categoryId, int page = 1)
    {
        var query = _context.NewsArticles.Include(a => a.NewsCategory).AsQueryable();

        if (!string.IsNullOrWhiteSpace(keyword))
        {
            var k = keyword.Trim();
            query = query.Where(a => a.Title.Contains(k));
        }

        if (categoryId is > 0) query = query.Where(a => a.NewsCategoryId == categoryId);

        ViewBag.Keyword = keyword;
        ViewBag.CategoryId = categoryId;
        ViewBag.Categories = await CategorySelectListAsync(categoryId);

        var model = await PagedList<NewsArticle>.CreateAsync(
            query.OrderByDescending(a => a.PublishedAt).AsNoTracking(), page, PageSize);

        return View(model);
    }

    [HttpGet]
    public async Task<IActionResult> Create()
    {
        ViewBag.Categories = await CategorySelectListAsync(null);
        return View(new NewsArticle
        {
            IsPublished = true,
            PublishedAt = DateTime.Now,
            Author = User.Identity?.Name
        });
    }

    [HttpPost]
    public async Task<IActionResult> Create(NewsArticle model, IFormFile? imageFile)
    {
        ModelState.Remove(nameof(NewsArticle.Slug));

        if (!ModelState.IsValid)
        {
            ViewBag.Categories = await CategorySelectListAsync(model.NewsCategoryId);
            return View(model);
        }

        var (ok, path, error) = await _upload.SaveImageAsync(imageFile, "news");
        if (!ok)
        {
            ModelState.AddModelError(string.Empty, error!);
            ViewBag.Categories = await CategorySelectListAsync(model.NewsCategoryId);
            return View(model);
        }

        model.Slug = SlugHelper.GenerateUnique(model.Title, s => _context.NewsArticles.Any(a => a.Slug == s));
        model.Content = _sanitizer.Sanitize(model.Content);   // chống XSS lưu trữ
        model.ImageUrl = path ?? "/images/news/no-image.svg";
        model.CreatedAt = DateTime.Now;
        model.ViewCount = 0;

        _context.NewsArticles.Add(model);
        await _context.SaveChangesAsync();

        TempData["Success"] = "Đã đăng bài viết mới.";
        return RedirectToAction(nameof(Index));
    }

    [HttpGet]
    public async Task<IActionResult> Edit(int id)
    {
        var article = await _context.NewsArticles.FindAsync(id);
        if (article is null) return NotFound();

        ViewBag.Categories = await CategorySelectListAsync(article.NewsCategoryId);
        return View(article);
    }

    [HttpPost]
    public async Task<IActionResult> Edit(int id, NewsArticle model, IFormFile? imageFile)
    {
        if (id != model.Id) return BadRequest();
        ModelState.Remove(nameof(NewsArticle.Slug));

        var article = await _context.NewsArticles.FindAsync(id);
        if (article is null) return NotFound();

        if (!ModelState.IsValid)
        {
            ViewBag.Categories = await CategorySelectListAsync(model.NewsCategoryId);
            return View(model);
        }

        var (ok, path, error) = await _upload.SaveImageAsync(imageFile, "news");
        if (!ok)
        {
            ModelState.AddModelError(string.Empty, error!);
            ViewBag.Categories = await CategorySelectListAsync(model.NewsCategoryId);
            return View(model);
        }

        if (!string.Equals(article.Title, model.Title, StringComparison.Ordinal))
            article.Slug = SlugHelper.GenerateUnique(model.Title, s => _context.NewsArticles.Any(a => a.Slug == s && a.Id != id));

        article.Title = model.Title;
        article.NewsCategoryId = model.NewsCategoryId;
        article.Summary = model.Summary;
        article.Content = _sanitizer.Sanitize(model.Content);
        article.Author = model.Author;
        article.IsPublished = model.IsPublished;
        article.IsFeatured = model.IsFeatured;
        article.PublishedAt = model.PublishedAt;

        if (path is not null)
        {
            _upload.Delete(article.ImageUrl);
            article.ImageUrl = path;
        }

        await _context.SaveChangesAsync();
        TempData["Success"] = "Đã cập nhật bài viết.";
        return RedirectToAction(nameof(Index));
    }

    [HttpPost]
    [Authorize(Policy = "AdminOnly")]
    public async Task<IActionResult> Delete(int id)
    {
        var article = await _context.NewsArticles.FindAsync(id);
        if (article is null) return NotFound();

        _upload.Delete(article.ImageUrl);
        _context.NewsArticles.Remove(article);
        await _context.SaveChangesAsync();

        TempData["Success"] = "Đã xoá bài viết.";
        return RedirectToAction(nameof(Index));
    }

    // ------------------------------------------------- Chuyên mục tin tức
    public async Task<IActionResult> Categories()
    {
        var categories = await _context.NewsCategories
            .Include(c => c.Articles)
            .OrderBy(c => c.DisplayOrder)
            .AsNoTracking()
            .ToListAsync();

        return View(categories);
    }

    [HttpPost]
    public async Task<IActionResult> CreateCategory(string name, int displayOrder)
    {
        if (string.IsNullOrWhiteSpace(name))
        {
            TempData["Error"] = "Tên chuyên mục không được để trống.";
            return RedirectToAction(nameof(Categories));
        }

        _context.NewsCategories.Add(new NewsCategory
        {
            Name = name.Trim(),
            Slug = SlugHelper.GenerateUnique(name, s => _context.NewsCategories.Any(c => c.Slug == s)),
            DisplayOrder = displayOrder,
            IsActive = true
        });

        await _context.SaveChangesAsync();
        TempData["Success"] = "Đã thêm chuyên mục.";
        return RedirectToAction(nameof(Categories));
    }

    [HttpPost]
    [Authorize(Policy = "AdminOnly")]
    public async Task<IActionResult> DeleteCategory(int id)
    {
        var category = await _context.NewsCategories
            .Include(c => c.Articles)
            .FirstOrDefaultAsync(c => c.Id == id);

        if (category is null) return NotFound();

        if (category.Articles.Count > 0)
        {
            TempData["Error"] = $"Không thể xoá chuyên mục đang có {category.Articles.Count} bài viết.";
            return RedirectToAction(nameof(Categories));
        }

        _context.NewsCategories.Remove(category);
        await _context.SaveChangesAsync();

        TempData["Success"] = "Đã xoá chuyên mục.";
        return RedirectToAction(nameof(Categories));
    }

    private async Task<SelectList> CategorySelectListAsync(int? selected)
    {
        var categories = await _context.NewsCategories
            .Where(c => c.IsActive)
            .OrderBy(c => c.DisplayOrder)
            .AsNoTracking()
            .ToListAsync();

        return new SelectList(categories, "Id", "Name", selected);
    }
}
