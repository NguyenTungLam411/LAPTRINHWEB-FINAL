using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ToanTechWeb.Data;
using ToanTechWeb.Models.Entities;
using ToanTechWeb.Services;

namespace ToanTechWeb.Areas.Admin.Controllers;

public class BusinessFieldsController : AdminBaseController
{
    private readonly ApplicationDbContext _context;
    private readonly IFileUploadService _upload;
    private readonly IHtmlSanitizerService _sanitizer;

    public BusinessFieldsController(ApplicationDbContext context, IFileUploadService upload, IHtmlSanitizerService sanitizer)
    {
        _context = context;
        _upload = upload;
        _sanitizer = sanitizer;
    }

    public async Task<IActionResult> Index()
    {
        var fields = await _context.BusinessFields
            .OrderBy(f => f.DisplayOrder)
            .AsNoTracking()
            .ToListAsync();

        return View(fields);
    }

    [HttpGet]
    public IActionResult Create() => View(new BusinessField { IsActive = true });

    [HttpPost]
    public async Task<IActionResult> Create(BusinessField model, IFormFile? imageFile)
    {
        ModelState.Remove(nameof(BusinessField.Slug));
        if (!ModelState.IsValid) return View(model);

        var (ok, path, error) = await _upload.SaveImageAsync(imageFile, "fields");
        if (!ok)
        {
            ModelState.AddModelError(string.Empty, error!);
            return View(model);
        }

        model.Slug = SlugHelper.GenerateUnique(model.Name, s => _context.BusinessFields.Any(f => f.Slug == s));
        model.Content = _sanitizer.Sanitize(model.Content);
        model.ImageUrl = path ?? "/images/fields/no-image.svg";
        model.CreatedAt = DateTime.Now;

        _context.BusinessFields.Add(model);
        await _context.SaveChangesAsync();

        TempData["Success"] = $"Đã thêm lĩnh vực \"{model.Name}\".";
        return RedirectToAction(nameof(Index));
    }

    [HttpGet]
    public async Task<IActionResult> Edit(int id)
    {
        var field = await _context.BusinessFields.FindAsync(id);
        if (field is null) return NotFound();
        return View(field);
    }

    [HttpPost]
    public async Task<IActionResult> Edit(int id, BusinessField model, IFormFile? imageFile)
    {
        if (id != model.Id) return BadRequest();
        ModelState.Remove(nameof(BusinessField.Slug));

        var field = await _context.BusinessFields.FindAsync(id);
        if (field is null) return NotFound();
        if (!ModelState.IsValid) return View(model);

        var (ok, path, error) = await _upload.SaveImageAsync(imageFile, "fields");
        if (!ok)
        {
            ModelState.AddModelError(string.Empty, error!);
            return View(model);
        }

        if (!string.Equals(field.Name, model.Name, StringComparison.Ordinal))
            field.Slug = SlugHelper.GenerateUnique(model.Name, s => _context.BusinessFields.Any(f => f.Slug == s && f.Id != id));

        field.Name = model.Name;
        field.Summary = model.Summary;
        field.Content = _sanitizer.Sanitize(model.Content);
        field.IconClass = model.IconClass;
        field.DisplayOrder = model.DisplayOrder;
        field.IsActive = model.IsActive;

        if (path is not null)
        {
            _upload.Delete(field.ImageUrl);
            field.ImageUrl = path;
        }

        await _context.SaveChangesAsync();
        TempData["Success"] = $"Đã cập nhật lĩnh vực \"{field.Name}\".";
        return RedirectToAction(nameof(Index));
    }

    [HttpPost]
    [Authorize(Policy = "AdminOnly")]
    public async Task<IActionResult> Delete(int id)
    {
        var field = await _context.BusinessFields.FindAsync(id);
        if (field is null) return NotFound();

        _upload.Delete(field.ImageUrl);
        _context.BusinessFields.Remove(field);
        await _context.SaveChangesAsync();

        TempData["Success"] = "Đã xoá lĩnh vực hoạt động.";
        return RedirectToAction(nameof(Index));
    }
}
