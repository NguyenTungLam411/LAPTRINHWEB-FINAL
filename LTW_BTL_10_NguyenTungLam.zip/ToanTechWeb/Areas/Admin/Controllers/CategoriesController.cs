using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using ToanTechWeb.Data;
using ToanTechWeb.Models.Entities;
using ToanTechWeb.Services;

namespace ToanTechWeb.Areas.Admin.Controllers;

public class CategoriesController : AdminBaseController
{
    private readonly ApplicationDbContext _context;

    public CategoriesController(ApplicationDbContext context) => _context = context;

    public async Task<IActionResult> Index()
    {
        var categories = await _context.Categories
            .Include(c => c.Parent)
            .Include(c => c.Products)
            .OrderBy(c => c.ParentId ?? c.Id)
            .ThenBy(c => c.DisplayOrder)
            .AsNoTracking()
            .ToListAsync();

        return View(categories);
    }

    [HttpGet]
    public async Task<IActionResult> Create()
    {
        await PopulateParentsAsync(null, null);
        return View(new Category { IsActive = true });
    }

    [HttpPost]
    public async Task<IActionResult> Create(Category model)
    {
        ModelState.Remove(nameof(Category.Slug));

        if (!ModelState.IsValid)
        {
            await PopulateParentsAsync(model.ParentId, null);
            return View(model);
        }

        model.Slug = SlugHelper.GenerateUnique(model.Name, s => _context.Categories.Any(c => c.Slug == s));
        _context.Categories.Add(model);
        await _context.SaveChangesAsync();

        TempData["Success"] = $"Đã thêm danh mục \"{model.Name}\".";
        return RedirectToAction(nameof(Index));
    }

    [HttpGet]
    public async Task<IActionResult> Edit(int id)
    {
        var category = await _context.Categories.FindAsync(id);
        if (category is null) return NotFound();

        await PopulateParentsAsync(category.ParentId, id);
        return View(category);
    }

    [HttpPost]
    public async Task<IActionResult> Edit(int id, Category model)
    {
        if (id != model.Id) return BadRequest();
        ModelState.Remove(nameof(Category.Slug));

        // Không cho chọn chính nó làm cha -> tránh vòng lặp vô hạn trong cây danh mục.
        if (model.ParentId == id)
            ModelState.AddModelError(nameof(Category.ParentId), "Danh mục không thể là cha của chính nó.");

        var category = await _context.Categories.FindAsync(id);
        if (category is null) return NotFound();

        if (!ModelState.IsValid)
        {
            await PopulateParentsAsync(model.ParentId, id);
            return View(model);
        }

        if (!string.Equals(category.Name, model.Name, StringComparison.Ordinal))
            category.Slug = SlugHelper.GenerateUnique(model.Name, s => _context.Categories.Any(c => c.Slug == s && c.Id != id));

        category.Name = model.Name;
        category.Description = model.Description;
        category.IconClass = model.IconClass;
        category.ParentId = model.ParentId;
        category.Kind = model.Kind;
        category.DisplayOrder = model.DisplayOrder;
        category.IsActive = model.IsActive;

        await _context.SaveChangesAsync();
        TempData["Success"] = $"Đã cập nhật danh mục \"{category.Name}\".";
        return RedirectToAction(nameof(Index));
    }

    [HttpPost]
    [Authorize(Policy = "AdminOnly")]
    public async Task<IActionResult> Delete(int id)
    {
        var category = await _context.Categories
            .Include(c => c.Children)
            .Include(c => c.Products)
            .FirstOrDefaultAsync(c => c.Id == id);

        if (category is null) return NotFound();

        if (category.Children.Count > 0)
        {
            TempData["Error"] = "Không thể xoá danh mục đang có danh mục con. Vui lòng xoá hoặc chuyển các danh mục con trước.";
            return RedirectToAction(nameof(Index));
        }

        if (category.Products.Count > 0)
        {
            TempData["Error"] = $"Không thể xoá danh mục đang chứa {category.Products.Count} sản phẩm.";
            return RedirectToAction(nameof(Index));
        }

        _context.Categories.Remove(category);
        await _context.SaveChangesAsync();

        TempData["Success"] = $"Đã xoá danh mục \"{category.Name}\".";
        return RedirectToAction(nameof(Index));
    }

    /// <summary>Nạp danh sách danh mục cha, loại trừ chính nó khi đang sửa.</summary>
    private async Task PopulateParentsAsync(int? selected, int? excludeId)
    {
        var roots = await _context.Categories
            .Where(c => c.ParentId == null && (excludeId == null || c.Id != excludeId))
            .OrderBy(c => c.DisplayOrder)
            .AsNoTracking()
            .ToListAsync();

        ViewBag.Parents = new SelectList(roots, "Id", "Name", selected);
    }
}
