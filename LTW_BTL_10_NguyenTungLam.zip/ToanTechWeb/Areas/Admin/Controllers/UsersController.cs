using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ToanTechWeb.Data;
using ToanTechWeb.Models.Entities;

namespace ToanTechWeb.Areas.Admin.Controllers;

/// <summary>
/// Quản lý tài khoản và phân quyền. Chỉ Administrator được vào,
/// vì đây là chức năng nhạy cảm nhất của hệ thống.
/// </summary>
[Authorize(Policy = "AdminOnly")]
public class UsersController : AdminBaseController
{
    private readonly UserManager<ApplicationUser> _userManager;
    private readonly RoleManager<IdentityRole> _roleManager;
    private readonly ApplicationDbContext _context;
    private readonly ILogger<UsersController> _logger;

    public UsersController(
        UserManager<ApplicationUser> userManager,
        RoleManager<IdentityRole> roleManager,
        ApplicationDbContext context,
        ILogger<UsersController> logger)
    {
        _userManager = userManager;
        _roleManager = roleManager;
        _context = context;
        _logger = logger;
    }

    public async Task<IActionResult> Index(string? keyword, string? role)
    {
        var users = await _userManager.Users
            .OrderByDescending(u => u.CreatedAt)
            .AsNoTracking()
            .ToListAsync();

        if (!string.IsNullOrWhiteSpace(keyword))
        {
            var k = keyword.Trim();
            users = users.Where(u =>
                u.FullName.Contains(k, StringComparison.OrdinalIgnoreCase) ||
                (u.Email ?? string.Empty).Contains(k, StringComparison.OrdinalIgnoreCase) ||
                (u.PhoneNumber ?? string.Empty).Contains(k)).ToList();
        }

        var rows = new List<(ApplicationUser User, IList<string> Roles, int OrderCount)>();
        foreach (var user in users)
        {
            var roles = await _userManager.GetRolesAsync(user);
            if (!string.IsNullOrWhiteSpace(role) && !roles.Contains(role)) continue;

            var orderCount = await _context.Orders.CountAsync(o => o.UserId == user.Id);
            rows.Add((user, roles, orderCount));
        }

        ViewBag.Keyword = keyword;
        ViewBag.Role = role;
        ViewBag.AllRoles = await _roleManager.Roles.Select(r => r.Name!).ToListAsync();

        return View(rows);
    }

    public async Task<IActionResult> Details(string id)
    {
        var user = await _userManager.FindByIdAsync(id);
        if (user is null) return NotFound();

        ViewBag.Roles = await _userManager.GetRolesAsync(user);
        ViewBag.AllRoles = await _roleManager.Roles.Select(r => r.Name!).ToListAsync();
        ViewBag.Orders = await _context.Orders
            .Where(o => o.UserId == id)
            .OrderByDescending(o => o.CreatedAt)
            .Take(10)
            .AsNoTracking()
            .ToListAsync();

        return View(user);
    }

    /// <summary>Gán lại vai trò cho một tài khoản.</summary>
    [HttpPost]
    public async Task<IActionResult> SetRole(string id, string role)
    {
        var user = await _userManager.FindByIdAsync(id);
        if (user is null) return NotFound();

        if (!RoleNames.All.Contains(role))
        {
            TempData["Error"] = "Vai trò không hợp lệ.";
            return RedirectToAction(nameof(Details), new { id });
        }

        // Không cho quản trị viên tự hạ quyền chính mình -> tránh khoá luôn hệ thống.
        if (user.Id == _userManager.GetUserId(User) && role != RoleNames.Administrator)
        {
            TempData["Error"] = "Bạn không thể tự thay đổi vai trò của chính mình.";
            return RedirectToAction(nameof(Details), new { id });
        }

        var currentRoles = await _userManager.GetRolesAsync(user);
        await _userManager.RemoveFromRolesAsync(user, currentRoles);
        await _userManager.AddToRoleAsync(user, role);

        _logger.LogWarning("{Admin} đã đổi vai trò của {User} thành {Role}",
            User.Identity?.Name, user.Email, role);

        TempData["Success"] = $"Đã gán vai trò \"{role}\" cho {user.FullName}.";
        return RedirectToAction(nameof(Details), new { id });
    }

    /// <summary>Khoá / mở khoá tài khoản.</summary>
    [HttpPost]
    public async Task<IActionResult> ToggleActive(string id)
    {
        var user = await _userManager.FindByIdAsync(id);
        if (user is null) return NotFound();

        if (user.Id == _userManager.GetUserId(User))
        {
            TempData["Error"] = "Bạn không thể tự khoá tài khoản của chính mình.";
            return RedirectToAction(nameof(Index));
        }

        user.IsActive = !user.IsActive;
        await _userManager.UpdateAsync(user);

        // Khoá tài khoản thì huỷ luôn các phiên đăng nhập đang mở.
        if (!user.IsActive)
            await _userManager.UpdateSecurityStampAsync(user);

        TempData["Success"] = user.IsActive
            ? $"Đã mở khoá tài khoản {user.Email}."
            : $"Đã khoá tài khoản {user.Email}.";

        return RedirectToAction(nameof(Index));
    }

    /// <summary>Đặt lại mật khẩu giúp khách hàng quên mật khẩu.</summary>
    [HttpPost]
    public async Task<IActionResult> ResetPassword(string id, string newPassword)
    {
        var user = await _userManager.FindByIdAsync(id);
        if (user is null) return NotFound();

        if (string.IsNullOrWhiteSpace(newPassword) || newPassword.Length < 8)
        {
            TempData["Error"] = "Mật khẩu mới phải có tối thiểu 8 ký tự.";
            return RedirectToAction(nameof(Details), new { id });
        }

        var token = await _userManager.GeneratePasswordResetTokenAsync(user);
        var result = await _userManager.ResetPasswordAsync(user, token, newPassword);

        if (result.Succeeded)
        {
            _logger.LogWarning("{Admin} đặt lại mật khẩu cho {User}", User.Identity?.Name, user.Email);
            TempData["Success"] = $"Đã đặt lại mật khẩu cho {user.Email}.";
        }
        else
        {
            TempData["Error"] = string.Join(" ", result.Errors.Select(e => e.Description));
        }

        return RedirectToAction(nameof(Details), new { id });
    }
}
