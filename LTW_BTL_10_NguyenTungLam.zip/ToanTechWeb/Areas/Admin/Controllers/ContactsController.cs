using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ToanTechWeb.Data;
using ToanTechWeb.Models.Entities;
using ToanTechWeb.Models.ViewModels;

namespace ToanTechWeb.Areas.Admin.Controllers;

public class ContactsController : AdminBaseController
{
    private const int PageSize = 15;

    private readonly ApplicationDbContext _context;

    public ContactsController(ApplicationDbContext context) => _context = context;

    public async Task<IActionResult> Index(bool? handled, int page = 1)
    {
        var query = _context.ContactMessages.AsQueryable();
        if (handled.HasValue) query = query.Where(c => c.IsHandled == handled);

        ViewBag.Handled = handled;
        ViewBag.UnhandledCount = await _context.ContactMessages.CountAsync(c => !c.IsHandled);

        var model = await PagedList<ContactMessage>.CreateAsync(
            query.OrderByDescending(c => c.CreatedAt).AsNoTracking(), page, PageSize);

        return View(model);
    }

    public async Task<IActionResult> Details(int id)
    {
        var message = await _context.ContactMessages.AsNoTracking().FirstOrDefaultAsync(c => c.Id == id);
        if (message is null) return NotFound();
        return View(message);
    }

    [HttpPost]
    public async Task<IActionResult> ToggleHandled(int id)
    {
        var message = await _context.ContactMessages.FindAsync(id);
        if (message is null) return NotFound();

        message.IsHandled = !message.IsHandled;
        await _context.SaveChangesAsync();

        TempData["Success"] = message.IsHandled
            ? "Đã đánh dấu liên hệ là đã xử lý."
            : "Đã chuyển liên hệ về trạng thái chưa xử lý.";

        return RedirectToAction(nameof(Index));
    }

    [HttpPost]
    [Authorize(Policy = "AdminOnly")]
    public async Task<IActionResult> Delete(int id)
    {
        var message = await _context.ContactMessages.FindAsync(id);
        if (message is null) return NotFound();

        _context.ContactMessages.Remove(message);
        await _context.SaveChangesAsync();

        TempData["Success"] = "Đã xoá liên hệ.";
        return RedirectToAction(nameof(Index));
    }
}
