using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using ToanTechWeb.Data;
using ToanTechWeb.Models.Entities;
using ToanTechWeb.Models.ViewModels;
using ToanTechWeb.Services;

namespace ToanTechWeb.Areas.Admin.Controllers;

public class ProductsController : AdminBaseController
{
    private const int PageSize = 15;

    private readonly ApplicationDbContext _context;
    private readonly IFileUploadService _upload;
    private readonly IHtmlSanitizerService _sanitizer;

    public ProductsController(
        ApplicationDbContext context,
        IFileUploadService upload,
        IHtmlSanitizerService sanitizer)
    {
        _context = context;
        _upload = upload;
        _sanitizer = sanitizer;
    }

    public async Task<IActionResult> Index(string? keyword, int? categoryId, int page = 1)
    {
        var query = _context.Products.Include(p => p.Category).AsQueryable();

        if (!string.IsNullOrWhiteSpace(keyword))
        {
            var k = keyword.Trim();
            query = query.Where(p => p.Name.Contains(k) || p.Sku.Contains(k));
        }

        if (categoryId is > 0)
            query = query.Where(p => p.CategoryId == categoryId);

        ViewBag.Keyword = keyword;
        ViewBag.CategoryId = categoryId;
        ViewBag.Categories = await BuildCategorySelectListAsync(categoryId);

        var model = await PagedList<Product>.CreateAsync(
            query.OrderByDescending(p => p.Id).AsNoTracking(), page, PageSize);

        return View(model);
    }

    [HttpGet]
    public async Task<IActionResult> Create()
    {
        ViewBag.Categories = await BuildCategorySelectListAsync(null);
        return View(new Product { IsActive = true, Sku = await SuggestSkuAsync() });
    }

    [HttpPost]
    public async Task<IActionResult> Create(Product model, IFormFile? imageFile)
    {
        // Slug do máy chủ sinh, không nhận từ form -> loại khỏi kiểm tra hợp lệ.
        ModelState.Remove(nameof(Product.Slug));

        if (await _context.Products.AnyAsync(p => p.Sku == model.Sku))
            ModelState.AddModelError(nameof(Product.Sku), "Mã sản phẩm này đã tồn tại.");

        if (!ModelState.IsValid)
        {
            ViewBag.Categories = await BuildCategorySelectListAsync(model.CategoryId);
            return View(model);
        }

        var (ok, path, error) = await _upload.SaveImageAsync(imageFile, "products");
        if (!ok)
        {
            ModelState.AddModelError(string.Empty, error!);
            ViewBag.Categories = await BuildCategorySelectListAsync(model.CategoryId);
            return View(model);
        }

        model.Slug = SlugHelper.GenerateUnique(model.Name, s => _context.Products.Any(p => p.Slug == s));
        model.Description = _sanitizer.Sanitize(model.Description);
        model.ImageUrl = path ?? "/images/products/no-image.svg";
        model.CreatedAt = DateTime.Now;
        model.ViewCount = 0;

        _context.Products.Add(model);
        await _context.SaveChangesAsync();

        TempData["Success"] = $"Đã thêm sản phẩm \"{model.Name}\".";
        return RedirectToAction(nameof(Index));
    }

    [HttpGet]
    public async Task<IActionResult> Edit(int id)
    {
        var product = await _context.Products.FindAsync(id);
        if (product is null) return NotFound();

        ViewBag.Categories = await BuildCategorySelectListAsync(product.CategoryId);
        return View(product);
    }

    [HttpPost]
    public async Task<IActionResult> Edit(int id, Product model, IFormFile? imageFile)
    {
        if (id != model.Id) return BadRequest();
        ModelState.Remove(nameof(Product.Slug));

        var product = await _context.Products.FindAsync(id);
        if (product is null) return NotFound();

        if (await _context.Products.AnyAsync(p => p.Sku == model.Sku && p.Id != id))
            ModelState.AddModelError(nameof(Product.Sku), "Mã sản phẩm này đã thuộc về sản phẩm khác.");

        if (!ModelState.IsValid)
        {
            ViewBag.Categories = await BuildCategorySelectListAsync(model.CategoryId);
            return View(model);
        }

        var (ok, path, error) = await _upload.SaveImageAsync(imageFile, "products");
        if (!ok)
        {
            ModelState.AddModelError(string.Empty, error!);
            ViewBag.Categories = await BuildCategorySelectListAsync(model.CategoryId);
            return View(model);
        }

        // Chỉ cập nhật các trường được phép sửa. KHÔNG dùng UpdateModel/TryUpdateModelAsync
        // trên toàn thực thể để tránh lỗi Mass Assignment (over-posting).
        if (!string.Equals(product.Name, model.Name, StringComparison.Ordinal))
            product.Slug = SlugHelper.GenerateUnique(model.Name, s => _context.Products.Any(p => p.Slug == s && p.Id != id));

        product.Sku = model.Sku;
        product.Name = model.Name;
        product.CategoryId = model.CategoryId;
        product.Brand = model.Brand;
        product.ShortDescription = model.ShortDescription;
        product.Description = _sanitizer.Sanitize(model.Description);
        product.Price = model.Price;
        product.OldPrice = model.OldPrice;
        product.StockQuantity = model.StockQuantity;
        product.IsFeatured = model.IsFeatured;
        product.IsActive = model.IsActive;
        product.UpdatedAt = DateTime.Now;

        if (path is not null)
        {
            _upload.Delete(product.ImageUrl);
            product.ImageUrl = path;
        }

        await _context.SaveChangesAsync();
        TempData["Success"] = $"Đã cập nhật sản phẩm \"{product.Name}\".";
        return RedirectToAction(nameof(Index));
    }

    public async Task<IActionResult> Details(int id)
    {
        var product = await _context.Products
            .Include(p => p.Category)
            .AsNoTracking()
            .FirstOrDefaultAsync(p => p.Id == id);

        if (product is null) return NotFound();
        return View(product);
    }

    /// <summary>Xoá sản phẩm. Chỉ Administrator mới được phép.</summary>
    [HttpPost]
    [Authorize(Policy = "AdminOnly")]
    public async Task<IActionResult> Delete(int id)
    {
        var product = await _context.Products.FindAsync(id);
        if (product is null) return NotFound();

        // Sản phẩm đã phát sinh đơn hàng thì chỉ ngừng kinh doanh, không xoá,
        // để giữ nguyên lịch sử đơn hàng cũ.
        if (await _context.OrderDetails.AnyAsync(d => d.ProductId == id))
        {
            product.IsActive = false;
            product.UpdatedAt = DateTime.Now;
            await _context.SaveChangesAsync();
            TempData["Warning"] = $"Sản phẩm \"{product.Name}\" đã có trong đơn hàng nên được chuyển sang trạng thái ngừng kinh doanh thay vì xoá.";
        }
        else
        {
            _upload.Delete(product.ImageUrl);
            _context.Products.Remove(product);
            await _context.SaveChangesAsync();
            TempData["Success"] = $"Đã xoá sản phẩm \"{product.Name}\".";
        }

        return RedirectToAction(nameof(Index));
    }

    [HttpPost]
    public async Task<IActionResult> ToggleActive(int id)
    {
        var product = await _context.Products.FindAsync(id);
        if (product is null) return NotFound();

        product.IsActive = !product.IsActive;
        product.UpdatedAt = DateTime.Now;
        await _context.SaveChangesAsync();

        return Json(new { success = true, isActive = product.IsActive });
    }

    // -------------------------------------------------------------- Tiện ích
    private async Task<SelectList> BuildCategorySelectListAsync(int? selected)
    {
        // Danh sách phẳng nhưng thụt lề để nhìn ra cấu trúc cây.
        var categories = await _context.Categories
            .OrderBy(c => c.ParentId ?? c.Id).ThenBy(c => c.DisplayOrder)
            .AsNoTracking()
            .ToListAsync();

        var items = new List<SelectListItem>();
        foreach (var root in categories.Where(c => c.ParentId is null).OrderBy(c => c.DisplayOrder))
        {
            items.Add(new SelectListItem($"{root.Name}", root.Id.ToString()));
            foreach (var child in categories.Where(c => c.ParentId == root.Id).OrderBy(c => c.DisplayOrder))
                items.Add(new SelectListItem($"    — {child.Name}", child.Id.ToString()));
        }

        return new SelectList(items, "Value", "Text", selected?.ToString());
    }

    private async Task<string> SuggestSkuAsync()
    {
        var count = await _context.Products.CountAsync();
        return $"SP-{count + 1:D4}";
    }
}
