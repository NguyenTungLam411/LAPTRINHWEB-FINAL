using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ToanTechWeb.Data;
using ToanTechWeb.Models.Entities;
using ToanTechWeb.Models.ViewModels;

namespace ToanTechWeb.Areas.Admin.Controllers;

/// <summary>Xử lý đơn hàng trực tuyến - phần quan trọng nhất của nghiệp vụ bán hàng.</summary>
public class OrdersController : AdminBaseController
{
    private const int PageSize = 15;

    private readonly ApplicationDbContext _context;
    private readonly ILogger<OrdersController> _logger;

    public OrdersController(ApplicationDbContext context, ILogger<OrdersController> logger)
    {
        _context = context;
        _logger = logger;
    }

    public async Task<IActionResult> Index(string? keyword, OrderStatus? status, DateTime? fromDate, DateTime? toDate, int page = 1)
    {
        var query = _context.Orders.AsQueryable();

        if (!string.IsNullOrWhiteSpace(keyword))
        {
            var k = keyword.Trim();
            query = query.Where(o => o.OrderCode.Contains(k)
                                  || o.CustomerName.Contains(k)
                                  || o.CustomerPhone.Contains(k)
                                  || o.CustomerEmail.Contains(k));
        }

        if (status.HasValue) query = query.Where(o => o.Status == status);
        if (fromDate.HasValue) query = query.Where(o => o.CreatedAt >= fromDate.Value.Date);
        if (toDate.HasValue) query = query.Where(o => o.CreatedAt < toDate.Value.Date.AddDays(1));

        ViewBag.Keyword = keyword;
        ViewBag.Status = status;
        ViewBag.FromDate = fromDate;
        ViewBag.ToDate = toDate;

        // Số liệu tóm tắt theo bộ lọc hiện tại.
        ViewBag.TotalRevenue = await query
            .Where(o => o.Status != OrderStatus.Cancelled)
            .SumAsync(o => (decimal?)o.TotalAmount) ?? 0;

        var model = await PagedList<Order>.CreateAsync(
            query.OrderByDescending(o => o.CreatedAt).AsNoTracking(), page, PageSize);

        return View(model);
    }

    public async Task<IActionResult> Details(int id)
    {
        var order = await _context.Orders
            .Include(o => o.OrderDetails)
            .Include(o => o.User)
            .AsNoTracking()
            .FirstOrDefaultAsync(o => o.Id == id);

        if (order is null) return NotFound();
        return View(order);
    }

    /// <summary>
    /// Chuyển trạng thái đơn hàng. Chỉ cho phép các bước chuyển hợp lệ theo quy
    /// trình nghiệp vụ, không cho nhảy cóc hay quay ngược từ đơn đã hoàn thành.
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> UpdateStatus(int id, OrderStatus status, string? cancelReason)
    {
        var order = await _context.Orders
            .Include(o => o.OrderDetails)
            .FirstOrDefaultAsync(o => o.Id == id);

        if (order is null) return NotFound();

        if (!IsValidTransition(order.Status, status))
        {
            TempData["Error"] = $"Không thể chuyển đơn hàng từ \"{Describe(order.Status)}\" sang \"{Describe(status)}\".";
            return RedirectToAction(nameof(Details), new { id });
        }

        // Huỷ đơn thì hoàn lại tồn kho.
        if (status == OrderStatus.Cancelled && order.Status != OrderStatus.Cancelled)
        {
            foreach (var detail in order.OrderDetails)
            {
                await _context.Products
                    .Where(p => p.Id == detail.ProductId)
                    .ExecuteUpdateAsync(s => s.SetProperty(p => p.StockQuantity, p => p.StockQuantity + detail.Quantity));
            }
            order.CancelReason = string.IsNullOrWhiteSpace(cancelReason)
                ? "Quản trị viên huỷ đơn."
                : cancelReason.Trim();
        }

        order.Status = status;
        order.UpdatedAt = DateTime.Now;
        await _context.SaveChangesAsync();

        _logger.LogInformation("Đơn {OrderCode} chuyển sang trạng thái {Status} bởi {User}",
            order.OrderCode, status, User.Identity?.Name);

        TempData["Success"] = $"Đã cập nhật đơn {order.OrderCode} sang trạng thái \"{Describe(status)}\".";
        return RedirectToAction(nameof(Details), new { id });
    }

    /// <summary>Trang in đơn hàng (phiếu giao hàng).</summary>
    public async Task<IActionResult> Print(int id)
    {
        var order = await _context.Orders
            .Include(o => o.OrderDetails)
            .AsNoTracking()
            .FirstOrDefaultAsync(o => o.Id == id);

        if (order is null) return NotFound();
        return View(order);
    }

    private static bool IsValidTransition(OrderStatus current, OrderStatus next) => current switch
    {
        OrderStatus.Pending => next is OrderStatus.Confirmed or OrderStatus.Cancelled,
        OrderStatus.Confirmed => next is OrderStatus.Shipping or OrderStatus.Cancelled,
        OrderStatus.Shipping => next is OrderStatus.Completed or OrderStatus.Cancelled,
        OrderStatus.Completed => false,   // đơn đã giao xong thì khoá lại
        OrderStatus.Cancelled => false,   // đơn đã huỷ không mở lại được
        _ => false
    };

    private static string Describe(OrderStatus status) => status switch
    {
        OrderStatus.Pending => "Chờ xác nhận",
        OrderStatus.Confirmed => "Đã xác nhận",
        OrderStatus.Shipping => "Đang giao hàng",
        OrderStatus.Completed => "Đã giao thành công",
        OrderStatus.Cancelled => "Đã huỷ",
        _ => status.ToString()
    };
}
