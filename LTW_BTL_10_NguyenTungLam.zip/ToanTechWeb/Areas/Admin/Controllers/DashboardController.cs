using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ToanTechWeb.Data;
using ToanTechWeb.Models.Entities;
using ToanTechWeb.Models.ViewModels;

namespace ToanTechWeb.Areas.Admin.Controllers;

/// <summary>
/// Lớp cơ sở cho MỌI controller trong khu vực quản trị.
/// Nhờ đặt [Authorize] ở đây, một controller mới thêm vào sau này
/// không thể "quên" phân quyền.
/// </summary>
[Area("Admin")]
[Authorize(Policy = "AdminArea")]
public abstract class AdminBaseController : Controller
{
}

public class DashboardController : AdminBaseController
{
    private readonly ApplicationDbContext _context;

    public DashboardController(ApplicationDbContext context) => _context = context;

    public async Task<IActionResult> Index()
    {
        var now = DateTime.Now;
        var firstDayOfMonth = new DateTime(now.Year, now.Month, 1);

        var model = new DashboardViewModel
        {
            TotalProducts = await _context.Products.CountAsync(p => p.IsActive),
            TotalOrders = await _context.Orders.CountAsync(),
            PendingOrders = await _context.Orders.CountAsync(o => o.Status == OrderStatus.Pending),
            TotalCustomers = await _context.Users.CountAsync(),
            TotalNews = await _context.NewsArticles.CountAsync(a => a.IsPublished),
            UnhandledContacts = await _context.ContactMessages.CountAsync(c => !c.IsHandled),

            RevenueThisMonth = await _context.Orders
                .Where(o => o.Status != OrderStatus.Cancelled && o.CreatedAt >= firstDayOfMonth)
                .SumAsync(o => (decimal?)o.TotalAmount) ?? 0,

            RevenueTotal = await _context.Orders
                .Where(o => o.Status != OrderStatus.Cancelled)
                .SumAsync(o => (decimal?)o.TotalAmount) ?? 0,

            RecentOrders = await _context.Orders
                .OrderByDescending(o => o.CreatedAt)
                .Take(8)
                .AsNoTracking()
                .ToListAsync(),

            LowStockProducts = await _context.Products
                .Include(p => p.Category)
                .Where(p => p.IsActive && p.StockQuantity <= 10)
                .OrderBy(p => p.StockQuantity)
                .Take(8)
                .AsNoTracking()
                .ToListAsync()
        };

        // Doanh thu 6 tháng gần nhất để vẽ biểu đồ.
        for (var i = 5; i >= 0; i--)
        {
            var monthStart = firstDayOfMonth.AddMonths(-i);
            var monthEnd = monthStart.AddMonths(1);

            var stats = await _context.Orders
                .Where(o => o.Status != OrderStatus.Cancelled
                            && o.CreatedAt >= monthStart && o.CreatedAt < monthEnd)
                .GroupBy(_ => 1)
                .Select(g => new { Amount = g.Sum(o => o.TotalAmount), Count = g.Count() })
                .FirstOrDefaultAsync();

            model.RevenueChart.Add(new MonthlyRevenue
            {
                Label = $"T{monthStart.Month}/{monthStart:yy}",
                Amount = stats?.Amount ?? 0,
                OrderCount = stats?.Count ?? 0
            });
        }

        return View(model);
    }
}
