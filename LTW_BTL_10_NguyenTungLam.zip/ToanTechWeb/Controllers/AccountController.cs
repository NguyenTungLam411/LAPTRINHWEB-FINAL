using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using ToanTechWeb.Models.Entities;
using ToanTechWeb.Models.ViewModels;

namespace ToanTechWeb.Controllers;

/// <summary>
/// Đăng ký, đăng nhập, đổi mật khẩu, cập nhật hồ sơ.
/// Toàn bộ thao tác với mật khẩu đều uỷ quyền cho ASP.NET Core Identity,
/// ứng dụng KHÔNG tự xử lý hoặc lưu mật khẩu dạng rõ.
/// </summary>
public class AccountController : Controller
{
    private readonly UserManager<ApplicationUser> _userManager;
    private readonly SignInManager<ApplicationUser> _signInManager;
    private readonly ILogger<AccountController> _logger;

    public AccountController(
        UserManager<ApplicationUser> userManager,
        SignInManager<ApplicationUser> signInManager,
        ILogger<AccountController> logger)
    {
        _userManager = userManager;
        _signInManager = signInManager;
        _logger = logger;
    }

    // ------------------------------------------------------------ Đăng nhập
    [HttpGet]
    public IActionResult Login(string? returnUrl = null)
    {
        if (User.Identity?.IsAuthenticated == true) return RedirectToAction("Index", "Home");
        return View(new LoginViewModel { ReturnUrl = returnUrl });
    }

    [HttpPost]
    [EnableRateLimiting("AuthPolicy")]
    public async Task<IActionResult> Login(LoginViewModel model)
    {
        if (!ModelState.IsValid) return View(model);

        var result = await _signInManager.PasswordSignInAsync(
            model.Email, model.Password, model.RememberMe, lockoutOnFailure: true);

        if (result.Succeeded)
        {
            var user = await _userManager.FindByEmailAsync(model.Email);

            if (user is { IsActive: false })
            {
                await _signInManager.SignOutAsync();
                ModelState.AddModelError(string.Empty, "Tài khoản của bạn đã bị khoá. Vui lòng liên hệ quản trị viên.");
                return View(model);
            }

            _logger.LogInformation("Người dùng {Email} đăng nhập thành công.", model.Email);

            // Nhân viên và quản trị viên vào thẳng trang quản trị.
            if (user is not null)
            {
                var roles = await _userManager.GetRolesAsync(user);
                if (roles.Contains(RoleNames.Administrator) || roles.Contains(RoleNames.Staff))
                    return RedirectToAction("Index", "Dashboard", new { area = "Admin" });
            }

            return RedirectToLocal(model.ReturnUrl);
        }

        if (result.IsLockedOut)
        {
            _logger.LogWarning("Tài khoản {Email} bị khoá tạm thời do đăng nhập sai nhiều lần.", model.Email);
            ModelState.AddModelError(string.Empty,
                "Tài khoản tạm thời bị khoá 15 phút do nhập sai mật khẩu quá 5 lần.");
            return View(model);
        }

        // Thông báo chung, KHÔNG tiết lộ email có tồn tại hay không (chống dò tài khoản).
        ModelState.AddModelError(string.Empty, "Email hoặc mật khẩu không đúng.");
        return View(model);
    }

    // -------------------------------------------------------------- Đăng ký
    [HttpGet]
    public IActionResult Register()
    {
        if (User.Identity?.IsAuthenticated == true) return RedirectToAction("Index", "Home");
        return View(new RegisterViewModel());
    }

    [HttpPost]
    [EnableRateLimiting("AuthPolicy")]
    public async Task<IActionResult> Register(RegisterViewModel model)
    {
        if (!ModelState.IsValid) return View(model);

        var user = new ApplicationUser
        {
            UserName = model.Email,
            Email = model.Email,
            FullName = model.FullName.Trim(),
            PhoneNumber = model.PhoneNumber,
            Address = model.Address?.Trim(),
            EmailConfirmed = true,
            CreatedAt = DateTime.Now
        };

        var result = await _userManager.CreateAsync(user, model.Password);

        if (result.Succeeded)
        {
            // Tài khoản tự đăng ký LUÔN chỉ được cấp vai trò Customer.
            // Vai trò Administrator/Staff chỉ do quản trị viên gán trong trang quản trị.
            await _userManager.AddToRoleAsync(user, RoleNames.Customer);
            await _signInManager.SignInAsync(user, isPersistent: false);

            _logger.LogInformation("Tài khoản mới đăng ký: {Email}", model.Email);
            TempData["Success"] = $"Chào mừng {user.FullName}! Tài khoản của bạn đã được tạo thành công.";
            return RedirectToAction("Index", "Home");
        }

        foreach (var error in result.Errors)
            ModelState.AddModelError(string.Empty, TranslateIdentityError(error));

        return View(model);
    }

    // ------------------------------------------------------------ Đăng xuất
    [HttpPost]
    [Authorize]
    public async Task<IActionResult> Logout()
    {
        await _signInManager.SignOutAsync();
        TempData["Success"] = "Bạn đã đăng xuất.";
        return RedirectToAction("Index", "Home");
    }

    // -------------------------------------------------------------- Hồ sơ
    [HttpGet]
    [Authorize]
    public async Task<IActionResult> Profile()
    {
        var user = await _userManager.GetUserAsync(User);
        if (user is null) return NotFound();

        return View(new ProfileViewModel
        {
            FullName = user.FullName,
            Email = user.Email ?? string.Empty,
            PhoneNumber = user.PhoneNumber,
            Address = user.Address,
            DateOfBirth = user.DateOfBirth
        });
    }

    [HttpPost]
    [Authorize]
    public async Task<IActionResult> Profile(ProfileViewModel model)
    {
        if (!ModelState.IsValid) return View(model);

        var user = await _userManager.GetUserAsync(User);
        if (user is null) return NotFound();

        user.FullName = model.FullName.Trim();
        user.PhoneNumber = model.PhoneNumber;
        user.Address = model.Address?.Trim();
        user.DateOfBirth = model.DateOfBirth;

        var result = await _userManager.UpdateAsync(user);
        if (result.Succeeded)
        {
            TempData["Success"] = "Đã cập nhật thông tin cá nhân.";
            return RedirectToAction(nameof(Profile));
        }

        foreach (var error in result.Errors)
            ModelState.AddModelError(string.Empty, TranslateIdentityError(error));

        return View(model);
    }

    // ------------------------------------------------------- Đổi mật khẩu
    [HttpGet]
    [Authorize]
    public IActionResult ChangePassword() => View(new ChangePasswordViewModel());

    [HttpPost]
    [Authorize]
    public async Task<IActionResult> ChangePassword(ChangePasswordViewModel model)
    {
        if (!ModelState.IsValid) return View(model);

        var user = await _userManager.GetUserAsync(User);
        if (user is null) return NotFound();

        // Bắt buộc nhập đúng mật khẩu hiện tại -> nếu kẻ tấn công chiếm được
        // phiên đăng nhập cũng không đổi được mật khẩu để chiếm luôn tài khoản.
        var result = await _userManager.ChangePasswordAsync(user, model.CurrentPassword, model.NewPassword);

        if (result.Succeeded)
        {
            await _signInManager.RefreshSignInAsync(user);
            TempData["Success"] = "Đổi mật khẩu thành công.";
            return RedirectToAction(nameof(Profile));
        }

        foreach (var error in result.Errors)
            ModelState.AddModelError(string.Empty, TranslateIdentityError(error));

        return View(model);
    }

    [HttpGet]
    public IActionResult AccessDenied() => View();

    // ------------------------------------------------------------ Tiện ích
    /// <summary>
    /// Chỉ chuyển hướng tới đường dẫn nội bộ. Nếu returnUrl trỏ ra ngoài
    /// thì bỏ qua - chống tấn công Open Redirect.
    /// </summary>
    private IActionResult RedirectToLocal(string? returnUrl)
    {
        if (!string.IsNullOrEmpty(returnUrl) && Url.IsLocalUrl(returnUrl))
            return Redirect(returnUrl);

        return RedirectToAction("Index", "Home");
    }

    /// <summary>Dịch thông báo lỗi mặc định của Identity sang tiếng Việt.</summary>
    private static string TranslateIdentityError(IdentityError error) => error.Code switch
    {
        "DuplicateUserName" or "DuplicateEmail" => "Email này đã được đăng ký.",
        "PasswordTooShort" => "Mật khẩu phải có tối thiểu 8 ký tự.",
        "PasswordRequiresDigit" => "Mật khẩu phải chứa ít nhất một chữ số.",
        "PasswordRequiresLower" => "Mật khẩu phải chứa ít nhất một chữ thường.",
        "PasswordRequiresUpper" => "Mật khẩu phải chứa ít nhất một chữ hoa.",
        "PasswordRequiresNonAlphanumeric" => "Mật khẩu phải chứa ít nhất một ký tự đặc biệt (!@#$...).",
        "PasswordMismatch" => "Mật khẩu hiện tại không đúng.",
        "InvalidEmail" => "Địa chỉ email không hợp lệ.",
        _ => error.Description
    };
}
