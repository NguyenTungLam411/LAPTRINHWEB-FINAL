using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ToanTechWeb.Data;
using ToanTechWeb.Models.Entities;
using ToanTechWeb.Models.ViewModels;

namespace ToanTechWeb.Controllers;

public class ProductController : Controller
{
    private const int PageSize = 9;

    private readonly ApplicationDbContext _context;

    public ProductController(ApplicationDbContext context) => _context = context;

    /// <summary>
    /// Danh sách sản phẩm có tìm kiếm, lọc theo danh mục / giá / thương hiệu,
    /// sắp xếp và phân trang. Tất cả tham số đều đi qua LINQ nên được EF Core
    /// tham số hoá - không ghép chuỗi SQL, do đó miễn nhiễm SQL Injection.
    /// </summary>
    public async Task<IActionResult> Index(
        string? keyword, int? categoryId, decimal? minPrice, decimal? maxPrice,
        string? brand, string sortBy = "newest", int page = 1)
    {
        var query = _context.Products
            .Include(p => p.Category)
            .Where(p => p.IsActive);

        // --- Lọc theo danh mục (bao gồm cả danh mục con) ---
        Category? currentCategory = null;
        if (categoryId is > 0)
        {
            currentCategory = await _context.Categories
                .Include(c => c.Children)
                .FirstOrDefaultAsync(c => c.Id == categoryId);

            if (currentCategory is not null)
            {
                var ids = currentCategory.Children.Select(c => c.Id).ToList();
                ids.Add(currentCategory.Id);
                query = query.Where(p => ids.Contains(p.CategoryId));
            }
        }

        if (!string.IsNullOrWhiteSpace(keyword))
        {
            var k = keyword.Trim();
            query = query.Where(p =>
                p.Name.Contains(k) ||
                p.Sku.Contains(k) ||
                (p.Brand != null && p.Brand.Contains(k)) ||
                (p.ShortDescription != null && p.ShortDescription.Contains(k)));
        }

        if (minPrice is > 0) query = query.Where(p => p.Price >= minPrice);
        if (maxPrice is > 0) query = query.Where(p => p.Price <= maxPrice);
        if (!string.IsNullOrWhiteSpace(brand)) query = query.Where(p => p.Brand == brand);

        query = sortBy switch
        {
            "price-asc" => query.OrderBy(p => p.Price),
            "price-desc" => query.OrderByDescending(p => p.Price),
            "name" => query.OrderBy(p => p.Name),
            "popular" => query.OrderByDescending(p => p.ViewCount),
            _ => query.OrderByDescending(p => p.CreatedAt)
        };

        var model = new ProductListViewModel
        {
            Products = await PagedList<Product>.CreateAsync(query.AsNoTracking(), page, PageSize),
            Categories = await _context.Categories
                .Include(c => c.Children.Where(x => x.IsActive))
                .Where(c => c.IsActive && c.ParentId == null)
                .OrderBy(c => c.DisplayOrder)
                .AsNoTracking()
                .ToListAsync(),
            AvailableBrands = await _context.Products
                .Where(p => p.IsActive && p.Brand != null)
                .Select(p => p.Brand!)
                .Distinct()
                .OrderBy(b => b)
                .ToListAsync(),
            CurrentCategory = currentCategory,
            Keyword = keyword,
            CategoryId = categoryId,
            MinPrice = minPrice,
            MaxPrice = maxPrice,
            Brand = brand,
            SortBy = sortBy,
            Page = page
        };

        return View(model);
    }

    /// <summary>Chi tiết sản phẩm, truy cập qua đường dẫn thân thiện /san-pham/{slug}.</summary>
    public async Task<IActionResult> Details(string slug)
    {
        if (string.IsNullOrWhiteSpace(slug)) return NotFound();

        var product = await _context.Products
            .Include(p => p.Category)
            .Include(p => p.Images.OrderBy(i => i.DisplayOrder))
            .FirstOrDefaultAsync(p => p.Slug == slug && p.IsActive);

        if (product is null) return NotFound();

        // Tăng lượt xem bằng lệnh UPDATE trực tiếp, tránh tải lại toàn bộ thực thể.
        await _context.Products
            .Where(p => p.Id == product.Id)
            .ExecuteUpdateAsync(s => s.SetProperty(p => p.ViewCount, p => p.ViewCount + 1));

        var model = new ProductDetailViewModel
        {
            Product = product,
            RelatedProducts = await _context.Products
                .Where(p => p.IsActive && p.CategoryId == product.CategoryId && p.Id != product.Id)
                .OrderByDescending(p => p.ViewCount)
                .Take(4)
                .AsNoTracking()
                .ToListAsync()
        };

        return View(model);
    }

    /// <summary>Gợi ý tìm kiếm cho ô search trên thanh điều hướng (gọi bằng AJAX).</summary>
    [HttpGet]
    public async Task<IActionResult> Suggest(string? term)
    {
        if (string.IsNullOrWhiteSpace(term) || term.Trim().Length < 2)
            return Json(Array.Empty<object>());

        var t = term.Trim();
        var items = await _context.Products
            .Where(p => p.IsActive && p.Name.Contains(t))
            .OrderByDescending(p => p.ViewCount)
            .Take(6)
            .Select(p => new { p.Name, p.Slug, p.Price, p.ImageUrl })
            .AsNoTracking()
            .ToListAsync();

        return Json(items);
    }
}
