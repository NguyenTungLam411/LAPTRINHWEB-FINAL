using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ToanTechWeb.Data;
using ToanTechWeb.Models.Entities;
using ToanTechWeb.Models.ViewModels;
using ToanTechWeb.Services;

namespace ToanTechWeb.Controllers;

public class HomeController : Controller
{
    private readonly ApplicationDbContext _context;
    private readonly IHtmlSanitizerService _sanitizer;
    private readonly ILogger<HomeController> _logger;

    public HomeController(ApplicationDbContext context, IHtmlSanitizerService sanitizer, ILogger<HomeController> logger)
    {
        _context = context;
        _sanitizer = sanitizer;
        _logger = logger;
    }

    public async Task<IActionResult> Index()
    {
        var model = new HomeViewModel
        {
            BusinessFields = await _context.BusinessFields
                .Where(f => f.IsActive)
                .OrderBy(f => f.DisplayOrder)
                .AsNoTracking()
                .ToListAsync(),

            FeaturedProducts = await _context.Products
                .Include(p => p.Category)
                .Where(p => p.IsActive && p.IsFeatured)
                .OrderByDescending(p => p.CreatedAt)
                .Take(8)
                .AsNoTracking()
                .ToListAsync(),

            NewProducts = await _context.Products
                .Include(p => p.Category)
                .Where(p => p.IsActive)
                .OrderByDescending(p => p.CreatedAt)
                .Take(8)
                .AsNoTracking()
                .ToListAsync(),

            RootCategories = await _context.Categories
                .Where(c => c.IsActive && c.ParentId == null)
                .OrderBy(c => c.DisplayOrder)
                .AsNoTracking()
                .ToListAsync(),

            LatestNews = await _context.NewsArticles
                .Include(a => a.NewsCategory)
                .Where(a => a.IsPublished)
                .OrderByDescending(a => a.PublishedAt)
                .Take(4)
                .AsNoTracking()
                .ToListAsync()
        };

        return View(model);
    }

    public IActionResult GioiThieu() => View();

    [HttpGet]
    public IActionResult LienHe() => View(new ContactMessage());

    /// <summary>
    /// Nhận form liên hệ. Có 3 lớp bảo vệ: anti-forgery token (tự động, khai báo
    /// toàn cục trong Program.cs), kiểm tra hợp lệ phía máy chủ, và giới hạn
    /// 3 lần gửi trong 5 phút cho mỗi địa chỉ IP.
    /// </summary>
    [HttpPost]
    [Microsoft.AspNetCore.RateLimiting.EnableRateLimiting("ContactPolicy")]
    public async Task<IActionResult> LienHe(ContactMessage model)
    {
        if (!ModelState.IsValid)
            return View(model);

        // Loại bỏ mọi thẻ HTML trong nội dung do khách gửi -> chống XSS lưu trữ.
        model.FullName = _sanitizer.Sanitize(model.FullName);
        model.Subject = _sanitizer.Sanitize(model.Subject);
        model.Message = _sanitizer.Sanitize(model.Message);
        model.IsHandled = false;
        model.CreatedAt = DateTime.Now;

        _context.ContactMessages.Add(model);
        await _context.SaveChangesAsync();

        _logger.LogInformation("Nhận liên hệ mới từ {Email}", model.Email);
        TempData["Success"] = "Cảm ơn bạn đã liên hệ! Chúng tôi sẽ phản hồi trong vòng 24 giờ làm việc.";
        return RedirectToAction(nameof(LienHe));
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        ViewBag.RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier;
        return View();
    }

    /// <summary>Trang thông báo cho các mã lỗi HTTP (404, 403...).</summary>
    [Route("Home/StatusCode")]
    public IActionResult StatusCodeHandler(int code)
    {
        ViewBag.Code = code;
        ViewBag.Message = code switch
        {
            400 => "Yêu cầu không hợp lệ.",
            403 => "Bạn không có quyền truy cập nội dung này.",
            404 => "Rất tiếc, không tìm thấy trang bạn yêu cầu.",
            429 => "Bạn thao tác quá nhanh. Vui lòng thử lại sau ít phút.",
            500 => "Máy chủ gặp sự cố. Chúng tôi đang khắc phục.",
            _ => "Đã có lỗi xảy ra."
        };
        return View("StatusCode");
    }
}
