using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ToanTechWeb.Data;
using ToanTechWeb.Models.Entities;
using ToanTechWeb.Models.ViewModels;

namespace ToanTechWeb.Controllers;

/// <summary>Tin tức về hoạt động của công ty - yêu cầu 4 của đề bài.</summary>
public class NewsController : Controller
{
    private const int PageSize = 6;

    private readonly ApplicationDbContext _context;

    public NewsController(ApplicationDbContext context) => _context = context;

    public async Task<IActionResult> Index(string? keyword, int? categoryId, int page = 1)
    {
        var query = _context.NewsArticles
            .Include(a => a.NewsCategory)
            .Where(a => a.IsPublished);

        if (categoryId is > 0)
            query = query.Where(a => a.NewsCategoryId == categoryId);

        if (!string.IsNullOrWhiteSpace(keyword))
        {
            var k = keyword.Trim();
            query = query.Where(a => a.Title.Contains(k) || (a.Summary != null && a.Summary.Contains(k)));
        }

        var model = new NewsListViewModel
        {
            Articles = await PagedList<NewsArticle>.CreateAsync(
                query.OrderByDescending(a => a.PublishedAt).AsNoTracking(), page, PageSize),

            Categories = await _context.NewsCategories
                .Where(c => c.IsActive)
                .OrderBy(c => c.DisplayOrder)
                .AsNoTracking()
                .ToListAsync(),

            FeaturedArticles = await _context.NewsArticles
                .Where(a => a.IsPublished && a.IsFeatured)
                .OrderByDescending(a => a.PublishedAt)
                .Take(5)
                .AsNoTracking()
                .ToListAsync(),

            CurrentCategory = categoryId is > 0
                ? await _context.NewsCategories.AsNoTracking().FirstOrDefaultAsync(c => c.Id == categoryId)
                : null,

            Keyword = keyword,
            CategoryId = categoryId
        };

        return View(model);
    }

    public async Task<IActionResult> Details(string slug)
    {
        if (string.IsNullOrWhiteSpace(slug)) return NotFound();

        var article = await _context.NewsArticles
            .Include(a => a.NewsCategory)
            .FirstOrDefaultAsync(a => a.Slug == slug && a.IsPublished);

        if (article is null) return NotFound();

        await _context.NewsArticles
            .Where(a => a.Id == article.Id)
            .ExecuteUpdateAsync(s => s.SetProperty(a => a.ViewCount, a => a.ViewCount + 1));

        var model = new NewsDetailViewModel
        {
            Article = article,
            RelatedArticles = await _context.NewsArticles
                .Where(a => a.IsPublished && a.NewsCategoryId == article.NewsCategoryId && a.Id != article.Id)
                .OrderByDescending(a => a.PublishedAt)
                .Take(4)
                .AsNoTracking()
                .ToListAsync()
        };

        return View(model);
    }
}
