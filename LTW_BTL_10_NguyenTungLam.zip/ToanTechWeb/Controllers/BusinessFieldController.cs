using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ToanTechWeb.Data;

namespace ToanTechWeb.Controllers;

/// <summary>Giới thiệu các lĩnh vực hoạt động của công ty - yêu cầu 1 của đề bài.</summary>
public class BusinessFieldController : Controller
{
    private readonly ApplicationDbContext _context;

    public BusinessFieldController(ApplicationDbContext context) => _context = context;

    public async Task<IActionResult> Index()
    {
        var fields = await _context.BusinessFields
            .Where(f => f.IsActive)
            .OrderBy(f => f.DisplayOrder)
            .AsNoTracking()
            .ToListAsync();

        return View(fields);
    }

    public async Task<IActionResult> Details(string slug)
    {
        if (string.IsNullOrWhiteSpace(slug)) return NotFound();

        var field = await _context.BusinessFields
            .AsNoTracking()
            .FirstOrDefaultAsync(f => f.Slug == slug && f.IsActive);

        if (field is null) return NotFound();

        ViewBag.OtherFields = await _context.BusinessFields
            .Where(f => f.IsActive && f.Id != field.Id)
            .OrderBy(f => f.DisplayOrder)
            .AsNoTracking()
            .ToListAsync();

        return View(field);
    }
}
