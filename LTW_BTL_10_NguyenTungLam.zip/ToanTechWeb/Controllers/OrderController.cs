using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ToanTechWeb.Data;
using ToanTechWeb.Models.Entities;
using ToanTechWeb.Models.ViewModels;
using ToanTechWeb.Services;

namespace ToanTechWeb.Controllers;

/// <summary>
/// Nghiệp vụ đặt hàng và tra cứu đơn hàng - yêu cầu 3 của đề bài
/// ("tiếp nhận đơn hàng, xử lý bán hàng trực tuyến").
/// </summary>
public class OrderController : Controller
{
    private readonly ApplicationDbContext _context;
    private readonly ICartService _cart;
    private readonly UserManager<ApplicationUser> _userManager;
    private readonly ILogger<OrderController> _logger;

    public OrderController(
        ApplicationDbContext context,
        ICartService cart,
        UserManager<ApplicationUser> userManager,
        ILogger<OrderController> logger)
    {
        _context = context;
        _cart = cart;
        _userManager = userManager;
        _logger = logger;
    }

    // ------------------------------------------------------------- Đặt hàng
    [HttpGet]
    public async Task<IActionResult> Checkout()
    {
        var cart = _cart.GetCart();
        if (cart.Items.Count == 0)
        {
            TempData["Warning"] = "Giỏ hàng đang trống. Vui lòng chọn sản phẩm trước khi đặt hàng.";
            return RedirectToAction("Index", "Product");
        }

        var model = new CheckoutViewModel { Cart = cart };

        // Đăng nhập rồi thì điền sẵn thông tin để khách đỡ phải gõ lại.
        if (User.Identity?.IsAuthenticated == true)
        {
            var user = await _userManager.GetUserAsync(User);
            if (user is not null)
            {
                model.CustomerName = user.FullName;
                model.CustomerEmail = user.Email ?? string.Empty;
                model.CustomerPhone = user.PhoneNumber ?? string.Empty;
                model.ShippingAddress = user.Address ?? string.Empty;
            }
        }

        return View(model);
    }

    [HttpPost]
    public async Task<IActionResult> Checkout(CheckoutViewModel model)
    {
        var cart = _cart.GetCart();
        model.Cart = cart;

        if (cart.Items.Count == 0)
        {
            TempData["Warning"] = "Giỏ hàng đang trống.";
            return RedirectToAction("Index", "Product");
        }

        if (!ModelState.IsValid) return View(model);

        // Chuỗi kết nối được cấu hình EnableRetryOnFailure, nên transaction do ta tự mở
        // phải nằm TRỌN trong một execution strategy. Nếu không, khi EF thử lại sau lỗi
        // kết nối tạm thời nó sẽ không biết phải chạy lại từ đâu và sẽ ném ngoại lệ.
        var strategy = _context.Database.CreateExecutionStrategy();

        var result = await strategy.ExecuteAsync<(Order? Order, string? Error)>(async () =>
        {
            await using var transaction = await _context.Database.BeginTransactionAsync();

            var productIds = cart.Items.Select(i => i.ProductId).ToList();
            var products = await _context.Products
                .Where(p => productIds.Contains(p.Id))
                .ToListAsync();

            var order = new Order
            {
                OrderCode = await GenerateOrderCodeAsync(),
                UserId = _userManager.GetUserId(User),
                CustomerName = model.CustomerName.Trim(),
                CustomerPhone = model.CustomerPhone.Trim(),
                CustomerEmail = model.CustomerEmail.Trim(),
                ShippingAddress = model.ShippingAddress.Trim(),
                Note = model.Note?.Trim(),
                PaymentMethod = model.PaymentMethod,
                Status = OrderStatus.Pending,
                CreatedAt = DateTime.Now
            };

            foreach (var item in cart.Items)
            {
                var product = products.FirstOrDefault(p => p.Id == item.ProductId);

                if (product is null || !product.IsActive)
                {
                    await transaction.RollbackAsync();
                    return (null, $"Sản phẩm \"{item.Name}\" không còn được kinh doanh. Vui lòng xoá khỏi giỏ hàng.");
                }

                if (product.StockQuantity < item.Quantity)
                {
                    await transaction.RollbackAsync();
                    return (null, $"Sản phẩm \"{product.Name}\" chỉ còn {product.StockQuantity} trong kho.");
                }

                // Giá tính lại từ CSDL tại thời điểm đặt, không lấy giá trong session.
                order.OrderDetails.Add(new OrderDetail
                {
                    ProductId = product.Id,
                    ProductName = product.Name,
                    UnitPrice = product.Price,
                    Quantity = item.Quantity,
                    LineTotal = product.Price * item.Quantity
                });

                product.StockQuantity -= item.Quantity;
            }

            order.SubTotal = order.OrderDetails.Sum(d => d.LineTotal);
            order.ShippingFee = cart.ShippingFee;
            order.TotalAmount = order.SubTotal + order.ShippingFee;

            _context.Orders.Add(order);
            await _context.SaveChangesAsync();
            await transaction.CommitAsync();

            return (order, null);
        });

        if (result.Order is null)
        {
            ModelState.AddModelError(string.Empty, result.Error!);
            return View(model);
        }

        _cart.Clear();
        _logger.LogInformation("Tạo đơn hàng {OrderCode}, tổng tiền {Total}",
            result.Order.OrderCode, result.Order.TotalAmount);

        return RedirectToAction(nameof(Success), new { code = result.Order.OrderCode });
    }

    public async Task<IActionResult> Success(string code)
    {
        if (string.IsNullOrWhiteSpace(code)) return NotFound();

        var order = await _context.Orders
            .Include(o => o.OrderDetails)
            .AsNoTracking()
            .FirstOrDefaultAsync(o => o.OrderCode == code);

        if (order is null) return NotFound();
        return View(order);
    }

    // ---------------------------------------------------------- Tra cứu đơn
    [HttpGet]
    public IActionResult Track() => View();

    [HttpPost]
    public async Task<IActionResult> Track(string orderCode, string phone)
    {
        if (string.IsNullOrWhiteSpace(orderCode) || string.IsNullOrWhiteSpace(phone))
        {
            ModelState.AddModelError(string.Empty, "Vui lòng nhập đủ mã đơn hàng và số điện thoại.");
            return View();
        }

        // Yêu cầu đúng CẢ mã đơn VÀ số điện thoại để người khác không dò được đơn hàng.
        var order = await _context.Orders
            .Include(o => o.OrderDetails)
            .AsNoTracking()
            .FirstOrDefaultAsync(o => o.OrderCode == orderCode.Trim() && o.CustomerPhone == phone.Trim());

        if (order is null)
        {
            ModelState.AddModelError(string.Empty, "Không tìm thấy đơn hàng khớp với thông tin đã nhập.");
            return View();
        }

        return View("TrackResult", order);
    }

    // -------------------------------------------------- Đơn hàng của tôi
    [Authorize]
    public async Task<IActionResult> MyOrders()
    {
        var userId = _userManager.GetUserId(User);

        var orders = await _context.Orders
            .Include(o => o.OrderDetails)
            .Where(o => o.UserId == userId)
            .OrderByDescending(o => o.CreatedAt)
            .AsNoTracking()
            .ToListAsync();

        return View(orders);
    }

    [Authorize]
    public async Task<IActionResult> Details(int id)
    {
        var userId = _userManager.GetUserId(User);

        // Điều kiện UserId == userId ngăn người dùng xem đơn của người khác
        // bằng cách sửa id trên URL (lỗi IDOR - Insecure Direct Object Reference).
        var order = await _context.Orders
            .Include(o => o.OrderDetails)
            .AsNoTracking()
            .FirstOrDefaultAsync(o => o.Id == id && o.UserId == userId);

        if (order is null) return NotFound();
        return View(order);
    }

    [Authorize]
    [HttpPost]
    public async Task<IActionResult> Cancel(int id)
    {
        var userId = _userManager.GetUserId(User);
        var order = await _context.Orders
            .Include(o => o.OrderDetails)
            .FirstOrDefaultAsync(o => o.Id == id && o.UserId == userId);

        if (order is null) return NotFound();

        // Chỉ được huỷ khi đơn chưa được xử lý.
        if (order.Status != OrderStatus.Pending)
        {
            TempData["Error"] = "Chỉ có thể huỷ đơn hàng đang ở trạng thái \"Chờ xác nhận\".";
            return RedirectToAction(nameof(Details), new { id });
        }

        order.Status = OrderStatus.Cancelled;
        order.CancelReason = "Khách hàng tự huỷ đơn.";
        order.UpdatedAt = DateTime.Now;

        // Trả lại tồn kho.
        foreach (var detail in order.OrderDetails)
        {
            await _context.Products
                .Where(p => p.Id == detail.ProductId)
                .ExecuteUpdateAsync(s => s.SetProperty(p => p.StockQuantity, p => p.StockQuantity + detail.Quantity));
        }

        await _context.SaveChangesAsync();
        TempData["Success"] = $"Đã huỷ đơn hàng {order.OrderCode}.";
        return RedirectToAction(nameof(MyOrders));
    }

    /// <summary>Sinh mã đơn dạng TTyyMMdd#### và kiểm tra không trùng.</summary>
    private async Task<string> GenerateOrderCodeAsync()
    {
        string code;
        do
        {
            code = $"TT{DateTime.Now:yyMMdd}{Random.Shared.Next(1000, 9999)}";
        } while (await _context.Orders.AnyAsync(o => o.OrderCode == code));

        return code;
    }
}
