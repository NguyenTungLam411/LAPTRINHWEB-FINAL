using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ToanTechWeb.Data;
using ToanTechWeb.Models.ViewModels;
using ToanTechWeb.Services;

namespace ToanTechWeb.Controllers;

public class CartController : Controller
{
    private readonly ApplicationDbContext _context;
    private readonly ICartService _cart;

    public CartController(ApplicationDbContext context, ICartService cart)
    {
        _context = context;
        _cart = cart;
    }

    public IActionResult Index() => View(_cart.GetCart());

    /// <summary>
    /// Thêm sản phẩm vào giỏ. Gọi bằng AJAX từ trang danh sách và trang chi tiết.
    /// Giá LUÔN được đọc lại từ CSDL, không bao giờ tin vào giá do trình duyệt gửi lên.
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> Add(int productId, int quantity = 1)
    {
        if (quantity < 1) quantity = 1;
        if (quantity > 100) quantity = 100;

        var product = await _context.Products
            .AsNoTracking()
            .FirstOrDefaultAsync(p => p.Id == productId && p.IsActive);

        if (product is null)
            return Json(new { success = false, message = "Sản phẩm không tồn tại hoặc đã ngừng kinh doanh." });

        if (product.StockQuantity <= 0)
            return Json(new { success = false, message = "Sản phẩm hiện đã hết hàng." });

        var alreadyInCart = _cart.GetItems().FirstOrDefault(i => i.ProductId == productId)?.Quantity ?? 0;
        if (alreadyInCart + quantity > product.StockQuantity)
            return Json(new { success = false, message = $"Chỉ còn {product.StockQuantity} sản phẩm trong kho." });

        _cart.AddItem(new CartItem
        {
            ProductId = product.Id,
            Name = product.Name,
            Slug = product.Slug,
            ImageUrl = product.ImageUrl,
            UnitPrice = product.Price,   // giá lấy từ CSDL
            Quantity = quantity
        });

        return Json(new
        {
            success = true,
            message = $"Đã thêm \"{product.Name}\" vào giỏ hàng.",
            cartCount = _cart.GetTotalQuantity()
        });
    }

    [HttpPost]
    public async Task<IActionResult> Update(int productId, int quantity)
    {
        var product = await _context.Products
            .AsNoTracking()
            .FirstOrDefaultAsync(p => p.Id == productId);

        if (product is not null && quantity > product.StockQuantity)
        {
            return Json(new
            {
                success = false,
                message = $"Chỉ còn {product.StockQuantity} sản phẩm trong kho."
            });
        }

        _cart.UpdateQuantity(productId, quantity);
        var cart = _cart.GetCart();

        return Json(new
        {
            success = true,
            cartCount = cart.TotalQuantity,
            subTotal = cart.SubTotal.ToString("N0"),
            shippingFee = cart.ShippingFee.ToString("N0"),
            total = cart.Total.ToString("N0"),
            lineTotal = cart.Items.FirstOrDefault(i => i.ProductId == productId)?.LineTotal.ToString("N0") ?? "0"
        });
    }

    [HttpPost]
    public IActionResult Remove(int productId)
    {
        _cart.RemoveItem(productId);
        TempData["Success"] = "Đã xoá sản phẩm khỏi giỏ hàng.";
        return RedirectToAction(nameof(Index));
    }

    [HttpPost]
    public IActionResult Clear()
    {
        _cart.Clear();
        TempData["Success"] = "Đã xoá toàn bộ giỏ hàng.";
        return RedirectToAction(nameof(Index));
    }

    /// <summary>Trả về số lượng trong giỏ để cập nhật badge trên thanh điều hướng.</summary>
    [HttpGet]
    public IActionResult Count() => Json(new { count = _cart.GetTotalQuantity() });
}
