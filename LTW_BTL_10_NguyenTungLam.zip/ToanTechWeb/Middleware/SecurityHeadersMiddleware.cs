namespace ToanTechWeb.Middleware;

/// <summary>
/// Gắn các HTTP security header vào mọi phản hồi.
/// Đây là lớp phòng thủ phía trình duyệt, bổ sung cho các biện pháp phía máy chủ.
/// </summary>
public class SecurityHeadersMiddleware
{
    private readonly RequestDelegate _next;

    public SecurityHeadersMiddleware(RequestDelegate next) => _next = next;

    public async Task InvokeAsync(HttpContext context)
    {
        var headers = context.Response.Headers;

        // Chặn trình duyệt tự "đoán" kiểu nội dung -> chống MIME sniffing.
        headers["X-Content-Type-Options"] = "nosniff";

        // Không cho nhúng site vào iframe của trang khác -> chống Clickjacking.
        headers["X-Frame-Options"] = "SAMEORIGIN";

        // Hạn chế thông tin Referer gửi sang trang khác.
        headers["Referrer-Policy"] = "strict-origin-when-cross-origin";

        // Khoá các API nhạy cảm của trình duyệt.
        headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=(), payment=()";

        // Content-Security-Policy: chỉ cho tải tài nguyên từ chính site và các CDN đã duyệt.
        headers["Content-Security-Policy"] =
            "default-src 'self'; " +
            "script-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net; " +
            "style-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net https://fonts.googleapis.com; " +
            "font-src 'self' https://cdn.jsdelivr.net https://fonts.gstatic.com data:; " +
            "img-src 'self' data: https:; " +
            "connect-src 'self'; " +
            "frame-ancestors 'self'; " +
            "base-uri 'self'; " +
            "form-action 'self'";

        // Không lộ việc site chạy trên Kestrel/ASP.NET.
        headers.Remove("Server");
        headers.Remove("X-Powered-By");

        await _next(context);
    }
}

public static class SecurityHeadersMiddlewareExtensions
{
    public static IApplicationBuilder UseSecurityHeaders(this IApplicationBuilder app)
        => app.UseMiddleware<SecurityHeadersMiddleware>();
}
